# PDE formalization and symmetry reduction

Updated: 2026-09-25. This checklist replaces conversational knowledge checks.
Current priority: a precise PDE-system input and a runnable Python reduction.
ML training and automatic maximal symmetry classification are later stages.

## Working contract

- [x] Reuse the approved generic `(p,q,r)` architecture in `symm/generic`.
- [x] Read the existing specification and approved implementation plan.
- [x] Establish the baseline: 15 core, jet and translation-reduction tests pass.
- [x] Represent fixed parameters, domain conditions and data surfaces explicitly.
- [x] Distinguish polynomial, rational and nonpolynomial dependence on jets.
- [x] Implement reduction in a supplied local chart for one projectable generator.
- [x] Verify a supplied off-shell symmetry identity, chart inverse and graph invariance.
- [x] Generate derivative substitutions by the chain rule for every field and equation.
- [x] Retain denominator, rank and branch conditions; never silently discard data.
- [x] Verify the SVE cubic reduction against an independently derived ODE.
- [x] Reject the cubic generator at a noncubic exponent when its identity fails.
- [x] Test multiple fields, `r != q`, remaining PDE variables and invalid charts.
- [x] Add the formalization and algorithm contract to `draft/main.tex`.
- [x] Run regression tests and compile the manuscript.

## Implementation sequence

1. Add mathematical behavior tests before implementation.
2. Add `PDEProblem` and `DataCondition` around the existing `DifferentialSystem`.
3. Add `ReductionChart` and `reduce_in_chart`; preserve the scalar API.
4. Supply an executable SVE example and explain inputs, outputs and limits.
5. Record fresh verification results here.

The reduction input includes a generator, invariant coordinates, an inverse
base-coordinate map, an affine field reconstruction and nonzero residual
factors. The algorithm checks these supplied objects; it does not claim to
discover every generator or integrate arbitrary characteristic systems.
It checks `pr(X) Delta = M Delta` for a supplied regular multiplier matrix.
Failure of that sufficient test does not prove that no symmetry exists.

## Mathematical practice and decisions

- [x] Separate a dependent coordinate, a field, its graph and its jet.
- [x] Separate the group-flow parameter epsilon from the model perturbation delta.
- [x] Use `p` for independent variables, `q` for fields, `r` for equations and `n` for order.
- [x] Treat PDE coefficients as fixed parameters during a symmetry action.
- [x] Use exact identities before statistical or sampled loss checks.
- [ ] Review the implemented formalization and worked SVE output when convenient.
- [ ] Select physical initial/boundary data after inspecting their pulled-back constraints.
- [ ] Extend beyond supplied charts and supplied symmetry multiplier identities.
- [ ] Revisit `m = 3 + delta` only after the exact cubic branch is reproducible.
- [ ] Define a neural task and training/evaluation measures after the mathematical baseline.

## Evidence boundaries

A verified result means a local, conditional identity for invariant fields in
the supplied chart. It does not prove a maximal Lie algebra, differential
completion, existence of solutions, global topology, or compatibility of an
arbitrary initial-boundary value problem. Data are pulled back as constraints
and retain a separate status. Nonpolynomial powers require a declared smooth
real branch. Numerical sampling is not part of exact symmetry verification.

## Verification on 2026-09-25

- Added 19 chart/formalization tests. Initial API and later guard-validation
  failures were observed before implementing the corresponding changes.
- `python -B -m pytest -q -p no:cacheprovider --ignore=symm/test_ml_pde_solver.py`:
  **130 passed**, exit 0. An existing Windows pytest temporary-directory
  cleanup emitted `PermissionError` after the successful test result.
- `python -B symm/test_ml_pde_solver.py`: **22 internal checks passed**, exit 0.
  Plain repository-wide pytest initially stopped in collection because this
  standalone script calls `sys.exit()` when imported. It was run separately,
  not omitted from verification. No test-runner repair was included here.
- SVE CLI: `m=3` gives `verified`, exit 0; `m=4` gives `unsupported`, exit 2,
  with the failed supplied symmetry identity retained in the output.
- `draft/main.tex` compiled twice with pdflatex. The 13-page PDF has resolved
  references and no overfull boxes; the existing bibliography has one underfull
  line warning. New methodology pages and final page flow were visually checked.
- `git diff --check` passed. Unrelated existing manuscript changes/deletions
  were preserved. Nothing was committed or submitted.

Read `docs/pde_formalization_and_reduction.md` for the executable interface,
positional jet-name convention and exact scope of the result.
