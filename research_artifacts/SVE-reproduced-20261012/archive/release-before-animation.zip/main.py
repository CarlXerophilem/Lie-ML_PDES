"""Run the complete SVE reproduction from any current working directory."""
from __future__ import annotations
import argparse
from contextlib import redirect_stdout
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import time

for _name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ.setdefault(_name,'1')

from sve_reproduce.sources import PACKAGE_ROOT, source_manifest
from sve_reproduce.models import build_model_report
from sve_reproduce.reporting import write_report, print_steps
from sve_reproduce.core import jsonable
from sve_reproduce.coverage import build_coverage


class Tee:
    def __init__(self,*streams): self.streams=streams
    def write(self,text):
        for stream in self.streams: stream.write(text)
        return len(text)
    def flush(self):
        for stream in self.streams: stream.flush()


def symbolic_certificate_summary(evidence):
    """Fail closed on the named calculations, not on paper disagreements."""
    failures=[]

    def get(*path):
        value=evidence
        for part in path:
            if not isinstance(value,dict) or part not in value:
                return None
            value=value[part]
        return value

    def require_true(*path):
        if get(*path) is not True:
            failures.append('.'.join(path))

    for name in ('mass_pullback_zero','momentum_pullback_zero',
                 'printed_compatibility_zero','physical_compatibility_zero'):
        require_true('models','checks',name)
    for name in ('X1','X2','X3','X4','X5','X6_m1',
                 'unrestricted_determining_split'):
        require_true('symmetries','checks',name,'passed')
    require_true('symmetries','checks','X5','m4_defect_nonzero')
    if get('symmetries','checks','X5','m3_defect') != '0':
        failures.append('symmetries.checks.X5.m3_defect')
    require_true('symmetries','checks','X6_m1','m2_nonzero')
    for name in ('free_y','free_w','free_a_b','free_a','free_x',
                 'm1_remaining_residual'):
        require_true('symmetries','checks','unrestricted_determining_split',name,'checked')
    for name in ('antisymmetry','jacobi','m1_jacobi'):
        passed=get('algebra','checks',name,'passed')
        total=get('algebra','checks',name,'total')
        if (type(passed) is not int or type(total) is not int
                or total <= 0 or passed != total):
            failures.append(f'algebra.checks.{name}')
    if get('algebra','checks','table_2','status') != 'agrees':
        failures.append('algebra.checks.table_2.status')
    return {'passed':not failures,'failures':failures}


def parse_args(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--stage',choices=['all','symbolic','numerical','report'],default='all')
    p.add_argument('--reduction',choices=['all']+[f'3.{i}' for i in range(1,10)]+['table3-mixed'],default='all')
    p.add_argument('--case',default='all',help='Numerical exponent/case selector, or all. Displayed reduction traces use cubic defaults; symbolic classification covers m>=1.')
    p.add_argument('--rtol',type=float,default=1e-9)
    p.add_argument('--atol',type=float,default=1e-11)
    p.add_argument('--out',type=Path,default=PACKAGE_ROOT/'results')
    p.add_argument('--trace',choices=['full','summary'],default='full')
    return p.parse_args(argv)


def main(argv=None):
    if hasattr(sys.stdout,'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8',errors='backslashreplace')
    args=parse_args(argv)
    if not (0<args.rtol<1 and 0<args.atol<1):
        raise SystemExit('rtol and atol must be between zero and one')
    args.out=args.out.resolve()
    args.out.mkdir(parents=True,exist_ok=True)
    if args.stage=='report':
        path=args.out/'evidence.json'
        if not path.exists(): raise SystemExit('No evidence.json: run symbolic or all first.')
        evidence=json.loads(path.read_text(encoding='utf-8'))
        summary=symbolic_certificate_summary(evidence)
        evidence.setdefault('run',{}).update(symbolic_passed=summary['passed'],
                                              symbolic_failures=summary['failures'])
        report=write_report(evidence,args.out)
        print(report)
        return 1 if not summary['passed'] or evidence['run'].get('numerical_passed') is False else 0
    started=time.perf_counter()
    evidence={'source_manifest':source_manifest(args.out),'models':build_model_report(),
              'numerics':{'status':'not_run'},'run':{
                  'started_utc':datetime.now(timezone.utc).isoformat(),
                  'stage':args.stage,'selection':args.reduction,'case':args.case,
                  'complete_audit':False,'source_agreement':'assessed_per_claim',
                  'numerical_scope':'constructed dimensionless local IVPs'}}
    with (args.out/'symbolic_steps.txt').open('w',encoding='utf-8') as log:
        stream=Tee(sys.stdout,log)
        with redirect_stdout(stream):
            print('SVE reproduction: source formulas are checked against independent calculations.',flush=True)
            print_steps('[master equation]',evidence['models']['steps'],stream)
            print('\nComputing point-symmetry and Lie-algebra certificates...',flush=True)
            from sve_reproduce.symmetries import build_symmetry_report
            from sve_reproduce.algebra import build_algebra_report
            evidence['symmetries']=build_symmetry_report()
            evidence['algebra']=build_algebra_report()
            for label,key in [('[Symmetries of the SVE Equation]','symmetries'),('[One-Dimensional Optimal System]','algebra')]:
                report=evidence[key]
                if args.trace=='full':
                    print(label,flush=True)
                    print(json.dumps(jsonable(report),indent=2,ensure_ascii=False),flush=True)
                else: print(label,'computed; full formulas saved in evidence.json',flush=True)
            print('\nDeriving the nine source reductions and Table 3 companion...',flush=True)
            from sve_reproduce.reductions import derive_reduction,build_reduction_report
            ids=[f'3.{i}' for i in range(1,10)]+['table3-mixed']
            for case in ids:
                if args.reduction not in ('all',case): continue
                row=derive_reduction(case,alpha=1 if case in ('3.7','3.8') else -1)
                print(f'\nReduction {case}: {row["status"]}',flush=True)
                if args.trace=='full': print_steps('Symbolic computation',row.get('steps',[]),stream)
                else: print('  residual:',row.get('residual'),' guards:',row.get('guards'),flush=True)
            evidence['reductions']=build_reduction_report()
            if args.stage in ('all','numerical'):
                print('\nRunning true Fehlberg RKF 4(5) and independent numerical checks...',flush=True)
                from sve_reproduce.numerics import run_campaign
                evidence['numerics']=run_campaign(args.out/'numerical',rtol=args.rtol,atol=args.atol,
                    selected_reduction=args.reduction,selected_case=args.case)
            evidence['run']['elapsed_seconds']=time.perf_counter()-started
            # Coverage and theorem status are finalized below without interpreting
            # a successfully executed source counterexample as source agreement.
            evidence['run']['execution_status']='finished'
            coverage=build_coverage(evidence)
            evidence['source_manifest'].update(coverage)
            evidence['run']['complete_audit']=coverage['inventory_complete']
            evidence['run']['all_printed_claims_reproduced']=False
            summary=symbolic_certificate_summary(evidence)
            evidence['run']['symbolic_passed']=summary['passed']
            evidence['run']['symbolic_failures']=summary['failures']
            evidence['run']['numerical_passed']=evidence['numerics'].get('all_passed')
            (args.out/'source_manifest.json').write_text(json.dumps(jsonable(evidence['source_manifest']),indent=2,ensure_ascii=False),encoding='utf-8')
            report_path=write_report(evidence,args.out)
            print('\nEvidence report:',report_path,flush=True)
            print('Read per-claim statuses; source discrepancies are retained.',flush=True)
    return 1 if not evidence['run']['symbolic_passed'] or evidence['run']['numerical_passed'] is False else 0


if __name__=='__main__':
    raise SystemExit(main())
