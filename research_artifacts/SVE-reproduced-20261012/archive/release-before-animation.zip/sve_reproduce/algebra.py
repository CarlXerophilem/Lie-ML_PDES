"""Independent coordinate-bracket and connected-adjoint audit of source Tables 1-2."""

from itertools import product

import sympy as sp

from . import core as j
from .symmetries import generators


_NAMES = ('X1', 'X2', 'X3', 'X4', 'X5')
_M1_NAMES = ('X1', 'X2', 'X3', 'X4', 'X6')
_COORDS = (j.t, j.s, j.u)


def bracket(left, right):
    """[left,right]=left(right)-right(left), as coordinate vector fields."""
    return tuple(sp.simplify(sum(left[k]*sp.diff(right[i], _COORDS[k])
                                 -right[k]*sp.diff(left[i], _COORDS[k])
                                 for k in range(3))) for i in range(3))


def _coordinates(vector, names=_NAMES):
    basis = generators()
    coefficients = sp.symbols('c1:6')
    equations = [sum(coefficients[k]*basis[names[k]][i] for k in range(5))-vector[i]
                 for i in range(3)]
    equations = [coefficient for expression in equations
                 for coefficient in sp.Poly(expression, j.t, j.s, j.u).coeffs()]
    answer = sp.solve(equations, coefficients, dict=True)
    if not answer:
        raise ValueError('vector is outside the declared Lie span')
    return {name: sp.simplify(answer[0][coefficient]) for name, coefficient in zip(names, coefficients)
            if answer[0].get(coefficient, 0) != 0}


def adjoint(actor, target, epsilon, stratum='m3'):
    """Source convention Ad(exp(eps A))B=exp(-eps ad_A)B."""
    names = _M1_NAMES if stratum == 'm1' else _NAMES
    if actor not in names or target not in names:
        raise ValueError('unknown generator')
    X = generators()
    if actor in ('X1','X2','X3','X6'):
        first = _coordinates(bracket(X[actor], X[target]), names)
        result = {target: sp.Integer(1)}
        for name, value in first.items():
            result[name] = sp.simplify(result.get(name, 0)-epsilon*value)
    else:
        first = _coordinates(bracket(X[actor], X[target]), names)
        if not first:
            result = {target: sp.Integer(1)}
        else:
            eigenvalue = first.get(target)
            if eigenvalue is None or len(first) != 1:
                raise ValueError('unexpected non-diagonal dilation')
            result = {target: sp.exp(-epsilon*eigenvalue)}
    return {name: value for name, value in result.items() if value != 0}


def orbit_invariants():
    """Orbit data, not a claim that the source list is an optimal system."""
    return {
        'generic': {
            'translation_projective_dimension': 2,
            'reason': 'Ad(X4) rescales all X1,X2,X3 equally, hence fixes each translation line.',
            'translation_representatives': ['X1+a*X2+b*X3 (a,b real)',
                                            'X2+a*X3 (a real)', 'X3'],
            'missing_source_family': 'X2+a*X3 (a nonzero), with projective parameter a',
            'nontranslation_line': 'X4 (translation terms removable)'},
        'exceptional': {
            'diagonal_weights_of_ad_aX4_bX5': {'X1':'-(a+b)', 'X2':'-(a-2b)', 'X3':'-a'},
            'resonant_directions': [
                {'H':'X5', 'survivor':'X3', 'family':'X5+c*X3'},
                {'H':'X4-X5', 'survivor':'X1', 'family':'X4-X5+c*X1'},
                {'H':'X4+(1/2)*X5', 'survivor':'X2', 'family':'X4+(1/2)*X5+c*X2'}],
            'resonant_c_connected_normal_forms': ['0','+1','-1'],
            'translation_line_invariant': 'I=a1**2*a2/a3**3 when a3!=0',
            'translation_invariant_scope': 'Ad(X5) and nonzero line rescaling; support and relative signs require separate strata',
            'translation_representatives': [
                'X1', 'X2', 'X3', 'X1+sigma*X2',
                'X3+sigma*X1', 'X3+sigma*X2',
                'X3+sigma*X1+K*X2'],
            'translation_parameters': 'sigma in {+1,-1}; K real nonzero; use only terms with their stated nonzero support',
            'nontranslation_representatives': 'H=aX4+bX5, (a:b) in RP1; at the three resonance directions add c*survivor, c=+1 or -1',
            'equivalence_test': 'For translation coefficients v,w: w=lambda*(exp(eps)*v1, exp(-2eps)*v2, v3), lambda real nonzero; for H+v, H projective fixed and nonresonant v removed by translations.',
            'source_optimality_status': 'refuted_incomplete'},
        'm1': {
            'basis':['X1','X2','X3','X4','X6'],
            'adjoint_elementary_actions': [
                'Ad(exp(eps X1)): v1->v1-eps*h, v3->v3-eps*c',
                'Ad(exp(eps X2)): v2->v2-eps*h',
                'Ad(exp(eps X3)): v3->v3-eps*h',
                'Ad(exp(eps X4)): (v1,v2,v3)->exp(eps)*(v1,v2,v3)',
                'Ad(exp(eps X6)): v3->v3+eps*v1'],
            'coordinates':'Z=v1*X1+v2*X2+v3*X3+h*X4+c*X6',
            'representatives': [
                'X4+alpha*X6 (alpha real)',
                'X6', 'X6+sigma*X1+a*X2 (sigma=+1 or -1, a real)',
                'X6+sigma*X2 (sigma=+1 or -1)',
                'X1+a*X2 (a real)', 'X2+a*X3 (a real)', 'X3'],
            'normalization': 'When c normalized to 1, X4 permits only positive common scaling of (v1,v2), so signs survive.',
            'classification_status':'connected-adjoint orbit representatives on the m=1 five-generator algebra'}}


def build_algebra_report():
    X = generators()
    zero = (sp.Integer(0),)*3
    brackets = {}
    anti = 0
    for a,b in product(_NAMES, repeat=2):
        ab = bracket(X[a], X[b])
        brackets[f'[{a},{b}]'] = {k:str(v) for k,v in _coordinates(ab).items()}
        anti += int(tuple(sp.simplify(v+w) for v,w in zip(ab,bracket(X[b],X[a]))) == zero)
    jacobi = 0
    for a,b,c in product(_NAMES, repeat=3):
        terms = [bracket(X[a],bracket(X[b],X[c])),
                 bracket(X[b],bracket(X[c],X[a])),
                 bracket(X[c],bracket(X[a],X[b]))]
        jacobi += int(all(sp.simplify(sum(term[i] for term in terms)) == 0 for i in range(3)))
    eps = sp.symbols('eps', real=True)
    adjoints = {f'Ad({a}){b}': {k:str(v) for k,v in adjoint(a,b,eps).items()}
                for a,b in product(_NAMES, repeat=2)}
    m1_brackets = {f'[{a},{b}]':{k:str(v) for k,v in _coordinates(bracket(X[a],X[b]), _M1_NAMES).items()}
                   for a,b in product(_M1_NAMES, repeat=2)}
    m1_jacobi = 0
    for a,b,c in product(_M1_NAMES, repeat=3):
        terms = [bracket(X[a],bracket(X[b],X[c])),
                 bracket(X[b],bracket(X[c],X[a])),
                 bracket(X[c],bracket(X[a],X[b]))]
        m1_jacobi += int(all(sp.simplify(sum(term[i] for term in terms)) == 0 for i in range(3)))
    m1_adjoints = {f'Ad({a}){b}':{k:str(v) for k,v in adjoint(a,b,eps,'m1').items()}
                   for a,b in product(_M1_NAMES, repeat=2)}
    return {
        'scope': {'source': 'v3 PDF pp. 4-6, Tables 1-2 and displayed one-dimensional system',
                  'convention': '[A,B]=A(B)-B(A); Ad(exp(eps A))B=exp(-eps ad_A)B',
                  'generic_basis':'X1-X4 for m!=1,3', 'm3_basis':'X1-X5', 'm1_basis':'X1-X4 plus X6',
                  'equivalence': 'connected inner adjoint plus nonzero line rescaling'},
        'claims': {'lie_algebra': {'status':'verified_for_listed_generators_only'},
                   'source_optimal_system': {'status':'refuted_incomplete'},
                   'complete_1d_classification': {'status':'derived_connected_inner_adjoint_with_line_scaling_on_each_declared_stratum'}},
        'formulas': {'brackets':brackets, 'adjoints':adjoints, 'm1_brackets':m1_brackets,
                     'm1_adjoints':m1_adjoints, 'orbits':orbit_invariants()},
        'checks': {'antisymmetry':{'passed':anti,'total':25},
                   'jacobi':{'passed':jacobi,'total':125},
                   'm1_jacobi':{'passed':m1_jacobi,'total':125},
                   'table_2':{'status':'agrees','convention':'negative ad'}},
        'discrepancies': {
            'table_1': {'wrong_cells':['[X5,X1]','[X5,X2]'],
                        'source_values':['+X1','-2X2'], 'correct_values':['-X1','+2X2'],
                        'proof':'antisymmetry and direct coordinate-vector bracket'},
            'one_dimensional_list': {
                'status':'refuted_incomplete',
                'generic_missing':'X2+aX3 for a!=0; X4 acts only by common rescaling on translation lines',
                'm3_missing':['X5+cX3','X4-X5+cX1','X4+(1/2)X5+cX2'],
                'qualification':'c!=0 witnesses cannot be removed by connected inner adjoint; sign and support strata require explicit tracking'},
            'm1_missing_generator': {
                'source':'v3 PDF p. 4 Proposition 1 and pp. 5-6 Tables 1-2/list, all omitting m=1 stratum',
                'generator':'X6=t*d_phi', 'new_bracket':'[X1,X6]=X3',
                'effect':'At m=1 the listed four-dimensional algebra is a proper subalgebra; its optimal list cannot be complete.'}}}
