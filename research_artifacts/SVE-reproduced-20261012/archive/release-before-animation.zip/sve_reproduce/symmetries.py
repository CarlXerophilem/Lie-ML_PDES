"""Direct point-symmetry identities for the printed scalar SVE equation (7)."""

import sympy as sp

from . import core as j


def generators():
    """Source v3 PDF p. 4, in (t,s,phi) coordinate order."""
    return {
        'X1': (sp.Integer(1), sp.Integer(0), sp.Integer(0)),
        'X2': (sp.Integer(0), sp.Integer(1), sp.Integer(0)),
        'X3': (sp.Integer(0), sp.Integer(0), sp.Integer(1)),
        'X4': (j.t, j.s, j.u),
        'X5': (j.t, -2*j.s, sp.Integer(0)),
        'X6': (sp.Integer(0), sp.Integer(0), j.t),
    }


def split_weight_identity():
    """pr X5(E_m)+E_m; only the bedload-flux term has wrong weight."""
    flux_part = -j.g*j.total(j.m*j.kappa*j.p**(j.m-1)*j.b/j.q, 1)
    return sp.expand((3-j.m)*flux_part)


def _determining_split():
    """Necessary free-jet coefficients, checked against unrestricted prolongation.

    At each stage earlier coefficients have set xi=xi(s), tau=tau(t), eta_s=0.
    The last residual verifies sufficiency for the only remaining m=1 function.
    """
    E = j.master()
    r_rhs = sp.solve(E, j.r)[0]
    tau = sp.Function('tau')(j.t,j.s,j.u)
    xi = sp.Function('xi')(j.t,j.s,j.u)
    eta = sp.Function('eta')(j.t,j.s,j.u)
    omega = j.act(E,tau,xi,eta).subs(j.r,r_rhs)
    factor = j.g*(j.kappa*j.m*j.p**j.m*j.q+j.p)/(j.p*j.q**2)
    y_expected = factor*(sp.diff(xi,j.t)+j.p*sp.diff(xi,j.u))
    y_ok = sp.simplify(sp.diff(omega,j.y)-y_expected) == 0

    xi_s = sp.Function('xi')(j.s)
    omega = j.act(E,tau,xi_s,eta).subs(j.r,r_rhs)
    w_expected = 2*factor*(sp.diff(tau,j.s)+j.q*sp.diff(tau,j.u))
    w_ok = sp.simplify(sp.diff(omega,j.w)-w_expected) == 0

    tau_t = sp.Function('tau')(j.t)
    omega = j.act(E,tau_t,xi_s,eta).subs(j.r,r_rhs)
    ab_expected = -sp.diff(eta,j.s)/j.q
    ab_ok = sp.simplify(sp.diff(omega,j.a,j.b)-ab_expected) == 0

    eta_tu = sp.Function('eta')(j.t,j.u)
    omega = j.act(E,tau_t,xi_s,eta_tu).subs(j.r,r_rhs)
    a_expected = j.q*(4*j.p*sp.diff(eta_tu,j.u,2)
                      -3*sp.diff(tau_t,j.t,2)+4*sp.diff(eta_tu,j.t,j.u))
    a_ok = sp.simplify(sp.diff(omega,j.a)-a_expected) == 0

    A = sp.Function('A')(j.t)
    B = sp.Function('B')(j.t)
    omega = j.act(E,tau_t,xi_s,A*j.u+B).subs(j.r,r_rhs)
    x_expected = -j.g/(j.p**2*j.q**2)*(
        j.kappa*j.m*j.p**j.m*j.q*((j.m-3)*j.p*(A-sp.diff(tau_t,j.t))
                            +(j.m-1)*(sp.diff(A,j.t)*j.u+sp.diff(B,j.t)))
        +j.p**2*(2*sp.diff(tau_t,j.t)+sp.diff(xi_s,j.s)-3*A))
    x_ok = sp.simplify(sp.diff(omega,j.x)-x_expected) == 0

    lam, t0, s0 = sp.symbols('lam t0 s0', real=True)
    E1 = j.master(1)
    rem = sp.factor(j.act(E1,lam*j.t+t0,lam*j.s+s0,lam*j.u+B)+2*lam*E1)
    rem_expected = j.b*sp.diff(B,j.t,2)+j.q*sp.diff(B,j.t,3)
    rem_ok = sp.simplify(rem-rem_expected) == 0
    return {
        'passed': all((y_ok,w_ok,ab_ok,a_ok,x_ok,rem_ok)),
        'free_y': {'coefficient':str(y_expected),'checked':y_ok,
                   'consequence':'xi_t=xi_u=0; common factor is positive on the branch'},
        'free_w': {'coefficient':str(w_expected),'checked':w_ok,
                   'consequence':'tau_s=tau_u=0'},
        'free_a_b': {'coefficient':str(ab_expected),'checked':ab_ok,
                     'consequence':'eta_s=0'},
        'free_a': {'coefficient':str(a_expected),'checked':a_ok,
                   'consequence':'eta=A(t)*u+B(t), 4*A_prime=3*tau_double_prime'},
        'free_x': {'coefficient':str(x_expected),'checked':x_ok,
                   'consequence':'2*tau_prime+xi_prime-3*A=0; (m-3)*p*(A-tau_prime)+(m-1)*(A_prime*u+B_prime)=0'},
        'm1_remaining_residual': {'expression':str(rem_expected),'checked':rem_ok,
                                   'consequence':'B_double_prime=0 by free b,q splitting'},
        'normal_form':str(r_rhs),
    }


def build_symmetry_report():
    E = j.master()
    X = generators()
    checks = {}
    for name, multiplier in [('X1', 0), ('X2', 0), ('X3', 0), ('X4', -2)]:
        difference = sp.simplify(j.act(E, *X[name])-multiplier*E)
        checks[name] = {'multiplier': str(multiplier), 'remainder': str(difference),
                        'passed': difference == 0, 'status': 'exact_off_shell'}
    difference = sp.simplify(j.act(E, *X['X5'])+E-split_weight_identity())
    checks['X5'] = {'identity_remainder': str(difference), 'passed': difference == 0,
                    'm3_defect': str(sp.simplify(split_weight_identity().subs(j.m, 3))),
                    'm4_defect_nonzero': sp.simplify(split_weight_identity().subs(j.m, 4)) != 0,
                    'status': 'exact_off_shell_weight_identity'}
    boost_1 = sp.simplify(j.act(j.master(1),*X['X6']))
    boost_2 = sp.simplify(j.act(j.master(2),*X['X6']))
    checks['X6_m1'] = {'remainder':str(boost_1),'passed':boost_1 == 0,
                       'm2_nonzero':boost_2 != 0, 'status':'exact_off_shell'}
    checks['unrestricted_determining_split'] = _determining_split()
    # On source p. 4, this printed determining equation gives 3+1+2=6 for X4.
    printed_witness = sp.Integer(3)*sp.Integer(1)+sp.diff(j.s,j.s)+2*sp.diff(j.t,j.t)
    return {
        'scope': {'equation': 'printed scalar equation (7), not advectively corrected/full bed system',
                  'branch': 'p=phi_t>0, q=phi_s>0, g>0, kappa>0, m>=1',
                  'category': 'local smooth point generators; direct third-jet prolongation',
                  'source': 'Paliathanasis, Leon, Leach, Mathematics 14 (2026) 433, v3 PDF pp. 4-5'},
        'claims': {
            'listed_generators': {'status': 'proved_direct_identity',
                                  'generic': ['X1','X2','X3','X4'], 'm3_extra': 'X5',
                                  'm1_extra_not_in_source':'X6=t*d_phi'},
            'maximal_classification': {'status': 'proved_on_declared_branch' if checks['unrestricted_determining_split']['passed'] else 'unresolved',
                                       'dimensions': {'m=1':5,'m=3':5,'m>=1,m!=1,3':4},
                                       'category':'unrestricted smooth local point generators on p,q>0; no singular p=0/q=0 branch'}},
        'formulas': {'E_m': str(E), 'X5_defect': str(split_weight_identity()),
                     'X5_weight_identity': 'pr3(X5)(E_m)+E_m=(3-m)*E_bedload',
                     'E_bedload': str(-j.g*j.total(j.m*j.kappa*j.p**(j.m-1)*j.b/j.q, 1))},
        'checks': checks,
        'discrepancies': {
            'printed_determining_X4_witness': {
                'source': 'v3 PDF p. 4, displayed determining system: 3 eta1 + xi2_s + 2 xi1_t = 0',
                'substitution': 'X4: eta1=1, xi2_s=1, xi1_t=1',
                'value': str(printed_witness), 'status': 'refuted_as_printed',
                'effect': 'The printed determining system cannot establish its Proposition 1 or maximality.'},
            'missing_m1_generator': {
                'source':'v3 PDF p. 4 Proposition 1: four for arbitrary m, fifth only m=3',
                'counterexample':'X6=t*d_phi at m=1; pr3(X6)(E_1)=0',
                'status':'refutes_source_maximal_count_at_m1',
                'corrected_dimension':'5 on the declared positive branch'}}}
