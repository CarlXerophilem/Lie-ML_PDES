"""Source equations (1)--(7): coordinate pullback and compatibility audit."""
import sympy as sp
from . import core as j


def build_model_report():
    p,q,a,b,c,g,k=j.p,j.q,j.a,j.b,j.c,j.g,j.kappa
    bs,bt=sp.symbols('b_s b_t',real=True)
    A=q*a-g*c/q**2
    transport=j.m*k*p**(j.m-1)*b/q
    # Eulerian derivatives at fixed spatial position, expressed on material jets.
    h_T=-b/q**2+p*c/q**3
    h_x=-c/q**3
    u_T=a-p*b/q
    u_x=b/q
    mass=sp.expand(h_T+p*h_x+u_x/q)
    momentum=sp.expand(u_T+p*u_x+g*(h_x+bs/q))
    printed_b_s=-A/g
    printed_b_t=-transport
    physical_b_t=-p*A/(g*q)-transport
    printed_closure=sp.expand(j.total(printed_b_s,0)-j.total(printed_b_t,1))
    physical_closure=sp.expand(j.total(printed_b_s,0)-j.total(physical_b_t,1))
    E=j.master()
    Ephys=sp.expand(E-j.total(p*A/q,1))
    checks={
        'mass_pullback_zero':mass==0,
        'momentum_pullback_zero':sp.expand(momentum-(a-g*c/q**3+g*bs/q))==0,
        'printed_compatibility_zero':sp.expand(printed_closure+E/g)==0,
        'physical_compatibility_zero':sp.expand(physical_closure+Ephys/g)==0,
    }
    steps=[
        ('Coordinate definitions','x=phi(t,s), h=1/phi_s, u=phi_t, b(t,s)=B(t,phi(t,s))'),
        ('Eulerian derivative operators','D_x=(1/q)D_s; D_T=D_t-(p/q)D_s'),
        ('Continuity pullback',mass),
        ('Momentum pullback',momentum),
        ('Exner pullback',bt-p*bs/q+transport),
        ('Printed Exner expression',bt+transport),
        ('Missing term under the pullback interpretation',-p*bs/q),
        ('Define A',A),
        ('Printed b_s',printed_b_s),
        ('Printed b_t',printed_b_t),
        ('Compatibility b_st-b_ts',printed_closure),
        ('Printed master equation E=0',E),
        ('Advectively corrected compatibility equation',Ephys),
    ]
    return j.jsonable({
        'model':'printed_scalar',
        'scope':'Local smooth material chart q>0; noninteger powers on p>0; g,kappa>0; m>=1.',
        'master':E,'master_latex':sp.latex(E),'beta':'m*kappa',
        'checks':checks,'steps':[{'label':a,'expression':b} for a,b in steps],
        'physical_equals_printed':sp.expand(E-Ephys)==0,
        'discrepancies':[{
            'id':'D-MODEL-06','source':'p.2 equation (6)',
            'printed':'b_t + beta*phi_t**(m-1)*phi_ts/phi_s = 0',
            'derived':'b_t - (phi_t/phi_s)*b_s + beta*phi_t**(m-1)*phi_ts/phi_s = 0',
            'witness':'D_T B = b_t - (p/q)b_s; the missing contribution is -p*b_s/q.',
            'status':'corrected_under_declared_bed_pullback',
            'qualification':'No inference about an alternative undefined bed variable; source equation (7) is retained as the mathematical reproduction target.'}],
        'reconstruction':'On a simply connected regular patch, E=0 closes omega=b_t dt+b_s ds and reconstructs the printed bed b up to a constant. This does not repair the Eulerian physical pullback.',
        'lagrangian_statement':'Lagrange coordinates describe material labels. The source says it could not find a variational Lagrangian; this is not a proof of nonexistence and no Noether argument is used.'})
