"""Finite third jets, unrestricted point prolongation and the printed PDE.

The expression is constructed from source equation (7), never from a printed
reduced equation. Third-order truncation is rejected rather than silently used.
"""
import sympy as sp

t, s, u = sp.symbols('t s u', real=True)
p, q = sp.symbols('p q', positive=True)
a, b, c, r, w, x, y = sp.symbols('a b c r w x y', real=True)
JETS = {(0,0):u,(1,0):p,(0,1):q,(2,0):a,(1,1):b,(0,2):c,
        (3,0):r,(2,1):w,(1,2):x,(0,3):y}
g, kappa = sp.symbols('g kappa', positive=True)
m = sp.symbols('m', real=True)
z = sp.symbols('z', positive=True)
F, P, C, H = sp.symbols('F P C H', real=True)


def total(expr, axis):
    expr = sp.sympify(expr)
    if axis not in (0, 1):
        raise ValueError('axis must be 0 or 1')
    result = sp.diff(expr, (t,s)[axis])
    for ij, jet in JETS.items():
        d = sp.diff(expr, jet)
        if d == 0:
            continue
        nxt = (ij[0]+int(axis==0), ij[1]+int(axis==1))
        if nxt not in JETS:
            raise ValueError('total derivative exceeds available jet order 3')
        result += JETS[nxt]*d
    return sp.expand(result)


def prolongation(tau, xi, eta):
    coeff = {(0,0):sp.sympify(eta)}
    dtau = [total(tau,i) for i in (0,1)]
    dxi = [total(xi,i) for i in (0,1)]
    for n in range(1,4):
        for i in range(n,-1,-1):
            j = n-i
            axis = 0 if i else 1
            prev = (i-1,j) if i else (i,j-1)
            coeff[(i,j)] = sp.expand(total(coeff[prev],axis)
                -JETS[(prev[0]+1,prev[1])]*dtau[axis]
                -JETS[(prev[0],prev[1]+1)]*dxi[axis])
    return coeff


def act(expr, tau, xi, eta):
    coeff = prolongation(tau,xi,eta)
    result = tau*sp.diff(expr,t)+xi*sp.diff(expr,s)
    result += sum(coeff[ij]*sp.diff(expr,jet) for ij,jet in JETS.items())
    return sp.expand(result)


def master(exponent=m):
    exponent = sp.sympify(exponent)
    A = q*a-g*c/q**2
    flux = exponent*kappa*p**(exponent-1)*b/q
    return total(A,0)-g*total(flux,1)


def profile_total(expr):
    return sp.diff(expr,z)+P*sp.diff(expr,F)+C*sp.diff(expr,P)+H*sp.diff(expr,C)


def jsonable(value):
    if isinstance(value, sp.Basic):
        return str(value)
    if isinstance(value, dict):
        return {str(k):jsonable(v) for k,v in value.items()}
    if isinstance(value, (list,tuple)):
        return [jsonable(v) for v in value]
    return value
