"""Classic six-stage Fehlberg 4(5) adaptive initial-value integrator."""
from dataclasses import dataclass
from fractions import Fraction as Q

import numpy as np


FEHLBERG_C = (Q(0), Q(1, 4), Q(3, 8), Q(12, 13), Q(1), Q(1, 2))
FEHLBERG_A = (
    (), (Q(1, 4),), (Q(3, 32), Q(9, 32)),
    (Q(1932, 2197), Q(-7200, 2197), Q(7296, 2197)),
    (Q(439, 216), Q(-8), Q(3680, 513), Q(-845, 4104)),
    (Q(-8, 27), Q(2), Q(-3544, 2565), Q(1859, 4104), Q(-11, 40)),
)
FEHLBERG_B4 = (Q(25, 216), Q(0), Q(1408, 2565), Q(2197, 4104), Q(-1, 5), Q(0))
FEHLBERG_B5 = (Q(16, 135), Q(0), Q(6656, 12825), Q(28561, 56430), Q(-9, 50), Q(2, 55))


class _StageFailure(Exception):
    def __init__(self, status):
        self.status = status


@dataclass
class RKFResult:
    t: np.ndarray
    y: np.ndarray
    status: str
    n_steps: int
    n_rejected: int
    nfev: int
    message: str


def _stage(fun, t, y, guard):
    if not np.all(np.isfinite(y)) or not np.isfinite(t):
        raise _StageFailure('nonfinite_stage')
    if guard is not None and not guard(t, y):
        raise _StageFailure('guard_stop')
    value = np.asarray(fun(t, y), dtype=float)
    if value.shape != y.shape or not np.all(np.isfinite(value)):
        raise _StageFailure('nonfinite_stage')
    return value


def _step(fun, t, y, h, guard=None):
    stages = []
    for i in range(6):
        trial = y + h * sum((float(a) * stages[j] for j, a in enumerate(FEHLBERG_A[i])), np.zeros_like(y))
        stages.append(_stage(fun, t + float(FEHLBERG_C[i]) * h, trial, guard))
    y4 = y + h * sum((float(b) * stages[i] for i, b in enumerate(FEHLBERG_B4)), np.zeros_like(y))
    y5 = y + h * sum((float(b) * stages[i] for i, b in enumerate(FEHLBERG_B5)), np.zeros_like(y))
    return y4, y5, y5 - y4


def rkf45_step(fun, t, y, h):
    """Return fourth estimate, accepted fifth estimate, and embedded difference."""
    return _step(fun, float(t), np.asarray(y, dtype=float), float(h))


def solve_ivp_rkf45(fun, t_span, y0, *, t_eval=None, rtol=1e-9, atol=1e-11,
                    first_step=None, min_step=1e-14, max_step=np.inf,
                    max_steps=100000, max_rejections=10000, guard=None):
    t0, end = map(float, t_span)
    y = np.atleast_1d(np.asarray(y0, dtype=float)).copy()
    if y.ndim != 1 or not np.all(np.isfinite(y)) or not np.isfinite([t0, end]).all():
        raise ValueError('finite scalar interval and finite one-dimensional initial state required')
    if end <= t0 or rtol <= 0 or atol <= 0 or min_step <= 0 or max_step <= 0:
        raise ValueError('positive forward interval, tolerances and step bounds required')
    if max_steps < 1 or max_rejections < 0:
        raise ValueError('invalid iteration limits')
    targets = None if t_eval is None else np.asarray(t_eval, dtype=float)
    if targets is not None and (targets.ndim != 1 or len(targets) == 0 or
            targets[0] < t0 or targets[-1] > end or np.any(np.diff(targets) <= 0)):
        raise ValueError('t_eval must be strictly increasing within t_span')
    h = min(float(first_step) if first_step is not None else (end - t0) / 20,
            max_step, end - t0)
    if h <= 0:
        raise ValueError('first_step must be positive')
    ts, ys = [t0], [y.copy()]
    t, steps, rejected, nfev = t0, 0, 0, 0

    def counted_rhs(stage_t, stage_y):
        nonlocal nfev
        nfev += 1
        return fun(stage_t, stage_y)

    next_target = 0
    if targets is not None and targets[0] == t0:
        next_target = 1
    status = 'completed'
    while t < end:
        if steps >= max_steps:
            status = 'step_limit'
            break
        target = end if targets is None or next_target >= len(targets) else targets[next_target]
        if target <= t:
            next_target += 1
            continue
        trial_h = min(h, target - t, end - t)
        if trial_h < min_step and target - t > 16 * np.spacing(t):
            status = 'step_underflow'
            break
        if t + trial_h == t:
            status = 'step_underflow'
            break
        try:
            y4, y5, diff = _step(counted_rhs, t, y, trial_h, guard)
            if not np.all(np.isfinite(y5)) or not np.all(np.isfinite(diff)):
                raise _StageFailure('nonfinite_stage')
            if guard is not None and not guard(t + trial_h, y5):
                raise _StageFailure('guard_stop')
        except _StageFailure as failure:
            status = failure.status
            break
        scale = atol + rtol * np.maximum(np.abs(y), np.abs(y5))
        error = float(np.sqrt(np.mean((diff / scale) ** 2)))
        factor = 5.0 if error == 0 else float(np.clip(0.9 * error ** (-1 / 5), 0.2, 5.0))
        if error <= 1:
            t = target if abs((t + trial_h) - target) <= 8 * np.spacing(target) else t + trial_h
            y = y5
            steps += 1
            if targets is None or t == target:
                ts.append(t)
                ys.append(y.copy())
            if targets is not None and t == target:
                next_target += 1
        else:
            rejected += 1
            if rejected > max_rejections:
                status = 'rejection_limit'
                break
        h = min(max_step, trial_h * factor)
    if targets is not None and status == 'completed' and next_target != len(targets):
        status = 'incomplete_grid'
    return RKFResult(np.asarray(ts), np.stack(ys, axis=1), status, steps, rejected,
                     nfev, status)
