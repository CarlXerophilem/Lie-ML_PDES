"""Independent pullbacks of the printed scalar PDE to Table 3 graphs."""
from functools import lru_cache

import sympy as sp

from . import core as j


def _D(expr):
    return j.profile_total(expr)


def _step(label, expression):
    return {'label': label, 'expression': expression}


def _result(case, status, coordinate, ansatz, residual=None, velocity=None,
            gradient=None, steps=(), guards=(), source_equations=()):
    if residual is not None:
        residual = sp.factor(residual)
        leading = sp.factor(sp.diff(residual, j.H))
        order = 3 if leading != 0 else (2 if residual.has(j.C) else 0)
        rhs = sp.cancel(-(residual - leading*j.H)/leading) if order == 3 else None
    else:
        leading, rhs, order = None, None, None
    return dict(id=case, status=status, coordinate=coordinate, ansatz=ansatz,
                residual=residual, leading=leading, rhs=rhs, velocity=velocity,
                gradient=gradient, ode_order=order, steps=list(steps),
                guards=list(guards), source_equations=list(source_equations))


def _scale(case, A, B, exponent, coordinate, ansatz, source_equations):
    # t^d Y(z) differentiates to t^(d-1)[dY+BzY']; s differentiation
    # adds B to the t exponent and differentiates Y with respect to z.
    V = A*j.F+B*j.z*j.P
    q = j.P
    a = (A-1)*V+B*j.z*_D(V)
    b = _D(V)
    c = j.C
    r = (A-2)*a+B*j.z*_D(a)
    w = _D(a)
    x = _D(b)
    y = j.H
    inertial = q*a-j.g*c/q**2
    flux = exponent*j.kappa*V**(exponent-1)*b/q
    residual = sp.factor(-A*inertial+B*j.z*_D(inertial)-j.g*_D(flux))
    steps = [_step('generator', f'X=t d_t + ({-B}) s d_s + ({A}) phi d_phi (rescaled)'),
             _step('invariant graph equation Q', A*j.F-((A*j.F+B*j.z*j.P)-B*j.z*j.P)),
             _step('invariant coordinate', coordinate),
             _step('invariant graph Q=0', ansatz),
             _step('phi_t at t=1', V), _step('phi_s at t=1', q),
             _step('phi_tt at t=1', a), _step('phi_ts at t=1', b),
             _step('phi_ss at t=1', c), _step('phi_ttt at t=1', r),
             _step('phi_tts at t=1', w), _step('phi_tss at t=1', x),
             _step('phi_sss at t=1', y),
             _step('inertial current profile', inertial),
             _step('sediment flux profile', flux),
             _step('PDE pullback multiplier', sp.Symbol('t')**(-A-1)),
             _step('reduced residual', residual)]
    if case == '3.4':
        integral = j.C*(-j.z**3*j.P+j.g*j.z/j.P**2+
                        j.g*exponent*j.kappa*j.z*V**(exponent-1)/j.P)
        steps.append(_step('first-integral density', sp.factor(integral)))
    guards = ['t>0', 'profile gradient P>0', 'profile velocity A*F+B*z*P>0',
              'highest-derivative coefficient nonzero']
    return _result(case, 'regular_ode', coordinate, ansatz, residual, V, q,
                   steps, guards, source_equations)


def _travel(case, exponent, alpha, alpha3):
    zc = j.s-alpha*j.t
    v = alpha3-alpha*j.P
    A = (alpha**2*j.P-j.g/j.P**2)*j.C
    flux = -alpha*exponent*j.kappa*v**(exponent-1)*j.C/j.P
    integral = sp.factor(A-j.g*exponent*j.kappa*v**(exponent-1)*j.C/j.P)
    residual = -alpha*_D(integral)
    ansatz = alpha3*j.t+j.F
    jets = [ansatz, v, j.P, alpha**2*j.C, -alpha*j.C, j.C,
            -alpha**3*j.H, alpha**2*j.H, -alpha*j.H, j.H]
    names = ['phi', 'phi_t', 'phi_s', 'phi_tt', 'phi_ts', 'phi_ss',
             'phi_ttt', 'phi_tts', 'phi_tss', 'phi_sss']
    steps = [_step('generator', f'd_t+({alpha})d_s+({alpha3})d_phi'),
             _step('invariant coordinate', zc),
             _step('invariant graph Q=0', ansatz)]
    steps += [_step(name, value) for name, value in zip(names,jets)]
    steps += [_step('inertial current', A), _step('sediment flux', flux),
              _step('PDE pullback multiplier', sp.Integer(1)),
              _step('first-integral density', integral),
              _step('reduced residual', residual)]
    if alpha == 0:
        return _result(case, 'identity', j.s, ansatz, sp.Integer(0), v, j.P,
                       steps, ['P>0', 'alpha3>0 for positive velocity'],
                       ['Table 3', '3.7' if alpha3 != 0 else '3.1'])
    return _result(case, 'regular_ode', zc, ansatz, residual, v, j.P, steps,
                   ['P>0', 'alpha3-alpha*P>0', 'alpha!=0',
                    'highest-derivative coefficient nonzero'],
                   ['(28)' if alpha3 == 0 else '(33)', '(29)-(31)' if alpha3 == 0 else '(34)'])


@lru_cache(maxsize=128)
def derive_reduction(case, exponent=3, alpha=-1, alpha3=1, mix_alpha=sp.Rational(1,4)):
    """Return exact local pullback; inputs are numbers, never evaluated strings."""
    case = str(case)
    exponent, alpha, alpha3, mix_alpha = map(sp.sympify,
                                             (exponent,alpha,alpha3,mix_alpha))
    if case == '3.1':
        return _result(case, 'identity', j.s, j.F, sp.Integer(0), 0, j.P,
                       [_step('generator', 'd_t'), _step('Q=0', 'phi_t=0'),
                        _step('jets', 'phi=F(s), phi_t=phi_ts=phi_tt=0; phi_s=P, phi_ss=C, phi_sss=H'),
                        _step('PDE pullback', sp.Integer(0))],
                       ['P>0', 'velocity=0 is outside the positive-velocity chart'], ['Table 3', '3.1'])
    if case == '3.2':
        return _result(case, 'undefined', j.t, j.F, None, j.P, 0,
                       [_step('generator','d_s'), _step('Q=0','phi_s=0'),
                        _step('jets','phi=F(t), phi_t=P, phi_tt=C, phi_ttt=H; phi_s=phi_ts=phi_ss=0'),
                        _step('denominator','phi_s^2=0')],
                       ['phi_s=0 violates the PDE domain'], ['Table 3','3.2'])
    if case == '3.3':
        return _result(case, 'no_invariant_graph', (j.t,j.s), None,
                       steps=[_step('generator','d_phi'), _step('Q=0','1=0')],
                       guards=['vertical orbit has no invariant graph'], source_equations=['Table 3','3.3'])
    if case == '3.4':
        return _scale(case, sp.Integer(1), sp.Integer(-1), exponent,
                      j.s/j.t, j.t*j.F, ['(24)'])
    if case == '3.5':
        if exponent != 3:
            raise ValueError('X5 is a symmetry only at exponent 3')
        return _scale(case, sp.Integer(0), sp.Integer(2), exponent,
                      j.s*j.t**2, j.F, ['(25)-(27)'])
    if case == '3.6':
        return _travel(case, exponent, alpha, sp.Integer(0))
    if case == '3.7':
        return _result(case, 'identity', j.s, alpha*j.t+j.F,
                       sp.Integer(0), alpha, j.P,
                       [_step('generator',f'd_t+({alpha})d_phi'),
                        _step('Q=0','phi_t=alpha'),
                        _step('jets','phi_t=alpha, phi_s=P, phi_ss=C; all mixed and higher time jets vanish'),
                        _step('PDE pullback',sp.Integer(0))],
                       ['P>0', 'alpha>0 for positive-velocity chart'], ['3.7'])
    if case == '3.8':
        residual = alpha*j.H
        return _result(case, 'regular_ode', j.t, alpha*j.s+j.F,
                       residual, j.P, alpha,
                       [_step('generator',f'd_s+({alpha})d_phi'),
                        _step('Q=0','phi_s=alpha'),
                        _step('jets','phi_t=P, phi_s=alpha, phi_tt=C, phi_ttt=H; all s-derivatives of order >=2 and mixed jets vanish'),
                        _step('PDE pullback',residual)],
                       ['alpha>0', 'P>0', 'alpha!=0'], ['(32)'])
    if case == '3.9':
        return _travel(case, exponent, alpha, alpha3)
    if case == 'table3-mixed':
        if exponent != 3 and mix_alpha != 0:
            raise ValueError('mixed X4+alpha*X5 is a symmetry only at exponent 3 unless alpha=0')
        if mix_alpha == -1:
            # X4-X5=3s*d_s+phi*d_phi; use s>0 as the transverse chart.
            A = sp.Rational(1,3)
            ansatz = j.s**A*j.F
            v, q = j.s**A*j.P, A*j.s**(A-1)*j.F
            # Substitute the complete original jet, then set s=1,t=z.
            f = sp.Function('f')(j.t)
            phi = j.s**A*f
            subs = {jet:sp.diff(phi,j.t,i,j.s,k).subs(j.s,1)
                    for (i,k),jet in j.JETS.items()}
            subs = {key: val.subs({f:j.F,sp.diff(f,j.t):j.P,
                    sp.diff(f,j.t,2):j.C,sp.diff(f,j.t,3):j.H})
                    for key,val in subs.items()}
            residual = sp.factor(j.master(3).subs(subs, simultaneous=True))
            steps = [_step('generator','3s*d_s+phi*d_phi'),
                     _step('invariants','t, phi*s^(-1/3)'),
                     _step('Q=0',ansatz)] + [
                     _step('jet '+str(ij), subs[jet]) for ij,jet in j.JETS.items()]
            steps += [_step('PDE pullback multiplier',j.s**(-A)),
                      _step('reduced residual at s=1',residual)]
            return _result(case,'regular_ode',j.t,ansatz,residual,v.subs(j.s,1),
                           q.subs(j.s,1),steps,['s>0','F>0','P>0',
                           'highest-derivative coefficient nonzero'],['Table 3'])
        A = sp.cancel(1/(1+mix_alpha))
        B = sp.cancel((2*mix_alpha-1)/(1+mix_alpha))
        return _scale(case,A,B,exponent,j.s*j.t**B,j.t**A*j.F,['Table 3'])
    raise ValueError(f'unknown reduction case: {case}')


def build_reduction_report():
    """JSON-safe evidence; exact certificates remain available from derive_reduction."""
    from .core import jsonable
    from .source_formulas import (common_scaling_first_integral,
        cubic_power_law_audit, printed_equation_witnesses,
        translated_ansatz_witnesses, traveling_first_integral)
    rows = [derive_reduction(f'3.{i}', alpha=1 if i in (7,8) else -1)
            for i in range(1,10)]
    mixed = derive_reduction('table3-mixed')
    return jsonable({'cases':rows, 'table3_mixed':mixed,
        'exact_certificates': {
            'common_scaling':common_scaling_first_integral(j.m),
            'traveling_3_6':traveling_first_integral(3,-1,0),
            'traveling_3_9':traveling_first_integral(3,-1,1),
            'cubic_power_law':cubic_power_law_audit()},
        'source_witnesses':printed_equation_witnesses(),
        'translation_witnesses':translated_ansatz_witnesses(),
        'further_reduction': {
            'common_scaling': 'I=C*(-z^3*P+g*z/P^2+g*m*kappa*z*(F-z*P)^(m-1)/P); dI/dz equals the third-order residual for symbolic m',
            'traveling_3.6_3.9': 'I=C*(alpha^2*P-g/P^2-g*m*kappa*(alpha3-alpha*P)^(m-1)/P); I is constant; for I!=0, dz/dP=B(P)/I',
            '3.8': 'H=0, so F(t)=c0+c1*t+c2*t^2/2',
            '3.5': 'translation in F permits mu=P, a second-order equation; additional scaling gives a rational first-order equation on 2*Sigma/3+M!=0'},
        'printed_comparison': {
            '3.1_3.2': 'Source subsection prose reverses Table 3: X1 gives F(s), X2 gives F(t); X2 is outside q>0 domain.',
            '3.7_3.8': 'Source subsection ansatzes are reversed. Correct 3.7: alpha*t+F(s), identity; correct 3.8: alpha*s+F(t), alpha*F_ttt=0.',
            '3.4': 'Printed cubic power profile and amplitude condition agree exactly, but the normal-form leading coefficient vanishes there; phi grows like t^(2/3) at fixed s>0.',
            '3.5': 'Printed (25)--(27) fail exact rational witnesses; source power profile is exact and (27) should have an additional 2*Sigma/3+M denominator.',
            '3.6_3.9': 'Printed (29), (31), (33) fail exact rational witnesses. Correct traveling residual is -alpha*dI/dz. Free-particle linearization is valid locally where B(P)!=0; (34) selects I=-1, not the general family.'}})
