"""Executable, source-audited scalar SVE reproduction."""
