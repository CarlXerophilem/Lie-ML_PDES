"""Versioned local sources and a complete numbered-equation inventory."""
import hashlib
import importlib.metadata
import json
import platform
import sys
from pathlib import Path

PACKAGE_ROOT=Path(__file__).resolve().parents[1]
REPO_ROOT=PACKAGE_ROOT.parents[1]
SOURCE_REL=Path('ref/main/Lie Symmetries and Similarity Solutions for a Shallow-Water Model with Bed Elevation in Lagrange Variables-mathematics-14-00433-v3.pdf')
METHOD_REL=Path('ref/Two parameters Liegroup analysis and numerical solution of unsteady free convective flow of non-Newtonian fluid.pdf')
REQUIRED_KEYS=[
    '[master equation]', '[infinitesimal generator]',
    '[Symmetries of the SVE Equation]',
    '[Commutators of the admitted Lie symmetries for the SVE equation]',
    '[listed Lie symmetries]', '[One-Dimensional Optimal System]',
    '[Similarity Transformations]',
    '[One dimensional optimal system and Lie invariants Table]',
    '[Solution ODE with all 9 reductions]', '[Numeric solutions to the ODEs]']


def equation_inventory():
    descriptions={
        1:'Eulerian mass balance',2:'Eulerian conservative momentum balance',
        3:'Exner bed balance',4:'Power-law sediment closure',
        5:'Lagrange momentum equation',6:'Printed Lagrange bed equation',
        7:'Printed third-order scalar master equation',
        8:'General PDE notation',9:'Infinitesimal time transformation',
        10:'Infinitesimal label transformation',11:'Infinitesimal field transformation',
        12:'General point infinitesimal generator',13:'Finite-to-infinitesimal invariance limit',
        14:'Prolonged infinitesimal criterion (on the equation manifold)',
        15:'Lie derivative of a scalar function',16:'First prolongation recursion',
        17:'Ellipsis in the displayed prolongation sequence',18:'Higher prolongation recursion',
        19:'Linear combinations of algebra basis elements',20:'Adjoint equivalence',
        21:'Nonzero generator rescaling',22:'Invariant characteristic equation',
        23:'Functions of invariants',24:'X4 reduced ODE',25:'X5 reduced ODE',
        26:'Derivative reduction of X5 ODE',27:'Claimed Abel equation',
        28:'Traveling-wave third-order ODE',29:'Traveling-wave derivative ODE',
        30:'Autonomous order reduction',31:'Claimed explicit reduced solution',
        32:'Claimed quadratic profile in subsection 3.8',
        33:'Shifted traveling-wave ODE',34:'Claimed implicit quadrature'}
    rows=[]
    for n in range(1,35):
        page=2 if n<=7 else 3 if n<=15 else 4 if n<=18 else 5 if n<=21 else 6 if n<=23 else 7 if n<=28 else 8 if n<=33 else 9
        owner='models' if n<=7 else 'symmetries' if n<=18 else 'algebra' if n<=21 else 'reductions'
        rows.append({'equation':n,'page':page,'description':descriptions[n],
                     'evidence_module':owner,'status':'pending_evidence'})
    return rows


def source_manifest(out_dir):
    import pymupdf
    out_dir=Path(out_dir)
    dest=out_dir/'sources'
    dest.mkdir(parents=True,exist_ok=True)
    sources=[]
    for source_id,rel,doi in [('SVE',SOURCE_REL,'10.3390/math14030433'),
                              ('RKF-reference',METHOD_REL,'10.1016/j.aej.2016.05.009')]:
        path=REPO_ROOT/rel
        blob=path.read_bytes()
        doc=pymupdf.open(path)
        text='\n\n'.join(f'=== PDF PAGE {i+1} ===\n'+page.get_text() for i,page in enumerate(doc))
        (dest/f'{source_id}.txt').write_text(text,encoding='utf-8')
        sources.append({'id':source_id,'path':rel.as_posix(),'doi':doi,
                        'sha256':hashlib.sha256(blob).hexdigest(),'pages':len(doc),
                        'verification':'local_primary_pdf_checked','accessed':'2026-10-12'})
    versions={}
    for name in ['sympy','numpy','scipy','matplotlib','pytest','pymupdf']:
        try: versions[name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError: versions[name]=None
    return {'sources':sources,'environment':{'python':sys.version,'platform':platform.platform(),'packages':versions},
            'method_scope':'Uddin et al. use RKF fourth-fifth order plus shooting for a different BVP; SVE initial data and algorithm tolerances here are newly specified.',
            'equations':equation_inventory(),'tables':[{'table':1,'page':5,'owner':'algebra'}, {'table':2,'page':5,'owner':'algebra'}, {'table':3,'page':6,'owner':'reductions'}]}
