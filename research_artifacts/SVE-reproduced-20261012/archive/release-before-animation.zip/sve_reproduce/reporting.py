"""Readable and machine-readable evidence output without claim promotion."""
import hashlib
import json
from pathlib import Path
from .core import jsonable
from .sources import REQUIRED_KEYS, PACKAGE_ROOT


def _bracket_table(brackets,names):
    parts=['| [row, column] | '+' | '.join(names)+' |',
           '|---|'+'---|'*len(names)]
    for a in names:
        cells=[]
        for b in names:
            terms=brackets.get(f'[{a},{b}]',{})
            cells.append(' + '.join(f'{v} {k}' for k,v in terms.items()) or '0')
        parts.append('| '+a+' | '+' | '.join(cells)+' |')
    return '\n'.join(parts)+'\n'


def _invariant_table(reductions):
    parts=['| Source row | Invariant coordinate | Invariant graph (F is evaluated at that coordinate) | Outcome |',
           '|---|---|---|---|']
    rows=list(reductions.get('cases',[]))
    if reductions.get('table3_mixed'):rows.append(reductions['table3_mixed'])
    for row in rows:
        parts.append(f'| {row["id"]} | `{row.get("coordinate")}` | `{row.get("ansatz")}` | {row["status"]} |')
    return '\n'.join(parts)+'\n'


def _render(value, level=3):
    if isinstance(value,dict):
        parts=[]
        for key,item in value.items():
            parts.append(f'{"#"*min(level,6)} {key.replace("_"," ")}\n')
            parts.append(_render(item,level+1))
        return '\n'.join(parts)
    if isinstance(value,list):
        if not value:
            return '(none)\n'
        return '\n'.join(_render(item,level) for item in value)
    if value is None:
        return 'Not applicable / not supplied.\n'
    text=str(value)
    if '\n' in text or len(text)>140 or any(x in text for x in ['**','Derivative(','Subs(']):
        return f'```text\n{text}\n```\n'
    return f'{text}\n'


def write_report(evidence,out_dir):
    out_dir=Path(out_dir)
    out_dir.mkdir(parents=True,exist_ok=True)
    evidence=jsonable(evidence)
    (out_dir/'evidence.json').write_text(json.dumps(evidence,indent=2,ensure_ascii=False),encoding='utf-8')
    model=evidence.get('models',{})
    sym=evidence.get('symmetries',{})
    algebra=evidence.get('algebra',{})
    reductions=evidence.get('reductions',{})
    numerical=evidence.get('numerics',{})
    sections=[model,
        {'general_point_generator':'X=tau(t,s,phi)*d_t+xi(t,s,phi)*d_s+eta(t,s,phi)*d_phi',
         'invariant_graph_characteristic':'Q=eta-tau*phi_t-xi*phi_s',
         'prolongation_recursion':'eta_(J,i)=D_i eta_J-phi_(J,t)D_i tau-phi_(J,s)D_i xi',
         'criterion':'pr^(3)X(E)=0 on E=0; a nonzero multiple of E is permitted off-shell.'},
        sym,algebra.get('formulas',{}).get('brackets',{}),
        {'source_four':'X1=d_t; X2=d_s; X3=d_phi; X4=t*d_t+s*d_s+phi*d_phi',
         'source_cubic_extra':'X5=t*d_t-2*s*d_s (m=3)',
         'additional_verified_endpoint':'X6=t*d_phi (m=1)',
         'classification':sym.get('claims',{}),
         'scope':sym.get('scope',sym.get('classification_status','See symmetry evidence above.'))},
        algebra,
        {'lagrangian_statement':model.get('lagrangian_statement',''),
         'method':'Solve Q=0, verify invariant chart, substitute every jet into original E. Dimension reduction and subsequent ODE order reduction are distinct.',
         'details':'See the per-case steps and further-reduction evidence below.'},
        reductions.get('invariants',reductions.get('invariant_table',{})),
        reductions,numerical]
    parts=['# Reproduction and independent audit of the scalar SVE paper\n',
           'This report distinguishes paper statements, exact checks, corrected results, and unresolved claims. '
           'Numerical IVPs are new constructed dimensionless examples. A successful execution does not certify every source claim.\n',
           '## Run status\n',_render(evidence.get('run',{})),
           '## Sources and complete equation inventory\n',_render(evidence.get('source_manifest',{}))]
    for index,(title,content) in enumerate(zip(REQUIRED_KEYS,sections)):
        parts.append(f'## {title}\n')
        if index==3:
            formulas=algebra.get('formulas',{})
            parts.extend(['Cubic stratum (the generic algebra is the X1--X4 block):\n',
                          _bracket_table(formulas.get('brackets',{}),['X1','X2','X3','X4','X5']),
                          'Endpoint m=1:\n',
                          _bracket_table(formulas.get('m1_brackets',{}),['X1','X2','X3','X4','X6'])])
        elif index==7:
            parts.append(_invariant_table(reductions))
        else:
            parts.append(_render(content))
    parts.append('## Detailed derivations and discrepancy explanations\n')
    docs=PACKAGE_ROOT/'docs'
    if docs.exists():
        for path in sorted(docs.glob('*.md')):
            if 'REVIEW' in path.name.upper():
                continue
            parts.extend([f'### {path.name}\n',path.read_text(encoding='utf-8')])
    (out_dir/'REPORT.md').write_text('\n'.join(parts),encoding='utf-8')
    code_hashes={p.relative_to(PACKAGE_ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in sorted(PACKAGE_ROOT.rglob('*.py')) if '__pycache__' not in p.parts}
    (out_dir/'code_manifest.json').write_text(json.dumps(code_hashes,indent=2),encoding='utf-8')
    return out_dir/'REPORT.md'


def print_steps(label,steps,stream):
    stream.write(f'\n{label}\n')
    for i,step in enumerate(steps,1):
        if isinstance(step,dict):
            text=step.get('expression',step.get('result',step))
            stream.write(f'  {i:02d}. {step.get("label",step.get("step","calculation"))}\n      {text}\n')
        else:
            stream.write(f'  {i:02d}. {step}\n')
    stream.flush()
