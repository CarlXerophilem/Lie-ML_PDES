"""Bounded IVP demonstrations and independent original-coordinate PDE checks."""
import csv
import json
from pathlib import Path
import time

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import solve_ivp
from scipy.interpolate import BarycentricInterpolator
import sympy as sp

from . import core as j
from .reductions import derive_reduction
from .rkf45 import solve_ivp_rkf45


G = 1.0
KAPPA = 1 / 30
CASES = ('3.4', '3.5', '3.6', '3.8', '3.9')
NON_NUMERICAL = ('3.1', '3.2', '3.3', '3.7', 'table3-mixed')
EXPONENTS = (1, 1.5, 2, 3, 4)
_OFFSETS = np.arange(-4, 5, dtype=float)


def _weights(order):
    powers = np.arange(9)
    matrix = _OFFSETS[None, :] ** powers[:, None]
    target = np.zeros(9)
    target[order] = float(sp.factorial(order))
    return np.linalg.solve(matrix, target)


_W = {degree: _weights(degree) for degree in range(4)}


def original_pde_residual(phi, t, s, *, m, h, g=G, kappa=KAPPA):
    """Differentiate reconstructed phi in both original coordinates.

    The 9-by-9 tensor stencil differentiates phi itself; no reduced ODE
    residual or formula for F''' is inserted in this diagnostic.
    """
    if h <= 0:
        raise ValueError('h must be positive')
    values = np.array([[phi(t + i*h, s + k*h) for k in _OFFSETS]
                       for i in _OFFSETS], dtype=float)
    if not np.all(np.isfinite(values)):
        return {'residual': float('nan'), 'velocity': float('nan'),
                'gradient': float('nan'), 'h': h}

    def d(i, k):
        return float(_W[i] @ values @ _W[k] / h**(i+k))

    p, q = d(1, 0), d(0, 1)
    a, b, c = d(2, 0), d(1, 1), d(0, 2)
    r, x = d(3, 0), d(1, 2)
    if p <= 0 or q <= 0:
        return {'residual': float('nan'), 'velocity': p,
                'gradient': q, 'h': h}
    inertial_t = b*a + q*r - g*(x/q**2 - 2*c*b/q**3)
    flux_s = m*kappa*((m-1)*p**(m-2)*b*b/q +
                       p**(m-1)*x/q - p**(m-1)*b*c/q**2)
    return {'residual': float(inertial_t-g*flux_s),
            'velocity': p, 'gradient': q, 'h': h}


def _selection(value, choices, name):
    if value == 'all':
        return choices
    if name == 'selected_case':
        try:
            selected = float(value)
        except (ValueError, TypeError) as exc:
            raise ValueError('selected_case must be one of 1, 1.5, 2, 3, 4 or all') from exc
        if selected not in choices:
            raise ValueError('unsupported exponent')
        return (selected,)
    if str(value) not in choices:
        raise ValueError('unsupported reduction')
    return (str(value),)


def _functions(reduction, exponent):
    substitutions = {j.g: G, j.kappa: KAPPA, j.m: exponent}
    args = (j.z, j.F, j.P, j.C)
    rhs_expr = reduction['rhs'].subs(substitutions)
    lead_expr = reduction['leading'].subs(substitutions)
    vel_expr = reduction['velocity'].subs(substitutions)
    grad_expr = reduction['gradient'].subs(substitutions)
    return tuple(sp.lambdify(args, expr, modules='numpy') for expr in
                 (rhs_expr, lead_expr, vel_expr, grad_expr))


def _coordinate_and_ansatz(reduction):
    coord = sp.lambdify((j.t, j.s), reduction['coordinate'], modules='numpy')
    ansatz = sp.lambdify((j.t, j.s, j.F), reduction['ansatz'], modules='numpy')
    return coord, ansatz


def _profile_guard(functions, deadline):
    _, lead, vel, grad = functions

    def check(z, y):
        if time.monotonic() > deadline or not np.all(np.isfinite(y)):
            return False
        try:
            v, q, coeff = float(vel(z, *y)), float(grad(z, *y)), float(lead(z, *y))
            return np.isfinite([v, q, coeff]).all() and v > 1e-9 and q > 1e-9 and abs(coeff) > 1e-10
        except (ValueError, FloatingPointError, OverflowError):
            return False
    return check


def _geometry(case, z):
    if case == '3.8':
        return z, 1.0
    if case in ('3.6', '3.9'):
        return 1.0, z - 1.0
    return 1.0, z


def _integral_drift(reduction, z, states, exponent):
    step = next((entry for entry in reduction['steps']
                 if entry['label'] == 'first-integral density'), None)
    if step is None:
        return {'status': 'no_certified_integral', 'scaled_drift': None}
    expr = step['expression'].subs({j.g: G, j.kappa: KAPPA, j.m: exponent})
    f = sp.lambdify((j.z, j.F, j.P, j.C), expr, modules='numpy')
    values = np.array([f(zi, *state) for zi, state in zip(z, states.T)], dtype=float)
    drift = float(np.max(np.abs(values-values[0])) / max(1.0, abs(values[0])))
    return {'status': 'passed' if drift <= 1e-7 else 'failed',
            'scaled_drift': drift, 'initial': float(values[0])}


def _rkf_interpolant(grid, states):
    width = min(12, len(grid))
    interpolators = [BarycentricInterpolator(grid[i:i+width], states[0, i:i+width], rng=0)
                     for i in range(len(grid)-width+1)]

    def evaluate(z):
        start = int(np.clip(np.searchsorted(grid, z)-width//2, 0,
                            len(interpolators)-1))
        return np.array([float(interpolators[start](z))])
    return evaluate


def _pde_check(reduction, dense, interval, case, exponent):
    coord, ansatz = _coordinate_and_ansatz(reduction)

    def phi(t, s):
        z = float(coord(t, s))
        if z < interval[0]-1e-12 or z > interval[1]+1e-12:
            raise ValueError('stencil left integrated profile interval')
        return float(ansatz(t, s, float(dense(z)[0])))

    points = np.linspace(interval[0]+0.45*(interval[1]-interval[0]),
                         interval[1]-0.45*(interval[1]-interval[0]), 3)
    refinements = []
    for h in (0.003, 0.002, 0.001):
        samples = [original_pde_residual(phi, *_geometry(case, z), m=exponent, h=h)
                   for z in points]
        refinements.append({'h': h,
                            'max_abs_residual': float(max(abs(x['residual']) for x in samples)),
                            'min_velocity': float(min(x['velocity'] for x in samples)),
                            'min_gradient': float(min(x['gradient'] for x in samples))})
    floor = min(x['max_abs_residual'] for x in refinements)
    acceptance = refinements[0]['max_abs_residual']
    min_v = min(x['min_velocity'] for x in refinements)
    min_q = min(x['min_gradient'] for x in refinements)
    z = (interval[0]+interval[1])/2
    t0, s0 = _geometry(case, z)
    baseline = original_pde_residual(phi, t0, s0, m=exponent, h=0.003)['residual']
    perturbed = original_pde_residual(lambda t, s: phi(t, s)+0.001*t**3,
                                      t0, s0, m=exponent, h=0.003)['residual']
    negative = {'baseline': baseline, 'perturbed': perturbed,
                'absolute_change': abs(perturbed-baseline),
                'passed': bool(np.isfinite(perturbed) and abs(perturbed-baseline) > 1e-4),
                'perturbation': 'phi + 0.001*t^3'}
    result = {'status': 'passed' if np.isfinite(acceptance) and acceptance <= 1e-6 and
            min_v > 0 and min_q > 0 else 'failed',
            'acceptance_h': 0.003, 'acceptance_max_abs_residual': acceptance,
            'error_floor': floor, 'refinements': refinements,
            'min_velocity': min_v, 'min_gradient': min_q,
            'stencil': 'nine-point tensor finite differences of reconstructed phi'}
    return result, negative


def _second_order_check(reduction, grid, third_order, y0, exponent):
    step = next((entry for entry in reduction['steps']
                 if entry['label'] == 'first-integral density'), None)
    if reduction['id'] != '3.4' or step is None:
        return {'status': 'not_applicable', 'scaled_disagreement': None}
    expr = step['expression'].subs({j.g: G, j.kappa: KAPPA, j.m: exponent})
    coefficient = sp.diff(expr, j.C)
    coefficient_fn = sp.lambdify((j.z, j.F, j.P), coefficient, modules='numpy')
    integral0 = float(sp.lambdify((j.z,j.F,j.P,j.C),expr,modules='numpy')(grid[0],*y0))
    def second(z, state):
        coeff = float(coefficient_fn(z, *state))
        if not np.isfinite(coeff) or abs(coeff) <= 1e-10:
            raise ValueError('second-order first-integral denominator crossed zero')
        return [state[1], integral0/coeff]
    solution = solve_ivp(second, (grid[0],grid[-1]), y0[:2], method='DOP853',
                         t_eval=grid, rtol=1e-12, atol=1e-14, max_step=0.01)
    if not solution.success:
        return {'status': 'failed', 'message': solution.message,
                'scaled_disagreement': None}
    error = float(np.max(np.abs(solution.y-third_order[:2])/
                         np.maximum(1, np.abs(third_order[:2]))))
    return {'status': 'passed' if error <= 1e-7 else 'failed',
            'scaled_disagreement': error, 'integral_constant': integral0}


def _write_plot(path, z, states, case, exponent):
    fig, ax = plt.subplots(figsize=(7.2, 4.0), layout='constrained')
    for values, label, color in zip(states, ('F', "F'", "F''"),
                                    ('#175a79', '#ba5a37', '#36855c')):
        ax.plot(z, values, lw=2, label=label, color=color)
    ax.set(xlabel='reduced coordinate', ylabel='profile / jet',
           title=f'Reduction {case} | m = {exponent:g}')
    ax.grid(alpha=.18)
    ax.legend(frameon=False, ncol=3)
    fig.savefig(path, dpi=160)
    plt.close(fig)


def run_campaign(out_dir, rtol=1e-9, atol=1e-11,
                 selected_reduction='all', selected_case='all'):
    """Run dimensionless IVPs; every failed gate remains explicit in the report."""
    output = Path(out_dir)
    output.mkdir(parents=True, exist_ok=True)
    selected = _selection(selected_reduction, CASES+NON_NUMERICAL, 'selected_reduction')
    exponents = _selection(selected_case, EXPONENTS, 'selected_case')
    runs = []
    non_numerical = []
    campaign_deadline = time.monotonic() + 600
    for case in selected:
        if case in NON_NUMERICAL:
            item = derive_reduction(case, exponent=3)
            non_numerical.append({'case': case, 'status':
                'symbolic_only_companion' if case == 'table3-mixed' else item['status'],
                'reason': 'no regular positive-branch IVP in this campaign'})
            continue
        for exponent in exponents:
            if case == '3.5' and exponent != 3:
                non_numerical.append({'case': case, 'm': exponent,
                    'status': 'incompatible_exponent',
                    'reason': 'X5 is a symmetry only at m=3'})
                continue
            row = {'case': case, 'm': exponent, 'model': 'printed scalar',
                   'g': G, 'kappa': KAPPA, 'beta': exponent*KAPPA}
            runs.append(row)
            if time.monotonic() > campaign_deadline:
                row['status'] = 'campaign_time_limit'
                continue
            try:
                reduction = derive_reduction(case, exponent=sp.Rational(str(exponent)),
                                             alpha=-1 if case != '3.8' else 1, alpha3=1)
                interval = (0.0, 0.4) if case == '3.8' else ((1.0, 1.4) if case == '3.4' else (1.0, 1.1))
                y0 = (0.0, 1.0, 0.1) if case == '3.8' else (2.0, 0.5, 0.1)
                row['interval'], row['initial_jet'] = interval, y0
                functions = _functions(reduction, exponent)
                guard = _profile_guard(functions, min(campaign_deadline, time.monotonic()+25))
                rhs = lambda z, state: np.array([state[1], state[2],
                                                 float(functions[0](z, *state))], dtype=float)
                grid = np.linspace(*interval, 81)
                rkf = solve_ivp_rkf45(rhs, interval, y0, t_eval=grid,
                                      rtol=rtol, atol=atol, max_steps=20000,
                                      max_rejections=2000, guard=guard)
                row['solver'] = {'status': rkf.status, 'steps': rkf.n_steps,
                                 'rejected': rkf.n_rejected, 'nfev': rkf.nfev}
                if rkf.status != 'completed':
                    row['status'] = 'solver_failed'
                    continue
                tighter = solve_ivp_rkf45(rhs, interval, y0, t_eval=grid,
                    rtol=rtol/10, atol=atol/10, max_steps=30000,
                    max_rejections=3000, guard=guard)
                if tighter.status != 'completed':
                    row['status'] = 'tight_solver_failed'
                    row['solver']['tight_status'] = tighter.status
                    continue
                length = interval[1]-interval[0]
                ladder = [solve_ivp_rkf45(rhs, interval, y0,
                    first_step=cap, max_step=cap,
                    rtol=tol, atol=absolute, max_steps=30000,
                    max_rejections=3000, guard=guard)
                    for tol, absolute, cap in ((rtol, atol, length/2),
                                               (rtol/10, atol/10, length/4))]
                if any(item.status != 'completed' for item in ladder):
                    row['status'] = 'ladder_solver_failed'
                    row['solver']['ladder_statuses'] = [item.status for item in ladder]
                    continue
                tight_disagreement = float(np.max(np.abs(ladder[0].y[:,-1]-ladder[1].y[:,-1])/
                    np.maximum(1, np.abs(ladder[1].y[:,-1]))))
                row['solver']['tight_ladder_disagreement'] = tight_disagreement
                row['solver']['ladder_steps'] = [item.n_steps for item in ladder]
                row['solver']['ladder_times'] = [item.t.tolist() for item in ladder]
                distinct = not np.array_equal(ladder[0].t, ladder[1].t)
                row['solver']['ladder_distinct_history'] = bool(distinct)
                row['solver']['ladder_interpretation'] = (
                    'roundoff_level_control' if tight_disagreement <= 1e-13 else
                    'finite_step_comparison')
                reference = solve_ivp(rhs, interval, y0, method='DOP853',
                                      t_eval=grid, dense_output=True,
                                      rtol=min(rtol/100, 1e-12),
                                      atol=min(atol/100, 1e-14), max_step=0.01)
                if not reference.success:
                    row['status'] = 'reference_failed'
                    row['reference_message'] = reference.message
                    continue
                disagreement = float(np.max(np.abs(rkf.y-reference.y)/
                                            np.maximum(1, np.abs(reference.y))))
                row['solver']['scaled_disagreement'] = disagreement
                if case == '3.8':
                    expected = np.vstack((y0[0]+y0[1]*grid+0.5*y0[2]*grid**2,
                                          y0[1]+y0[2]*grid,
                                          np.full_like(grid, y0[2])))
                    quadratic_error = float(np.max(np.abs(rkf.y-expected)))
                    row['exact_quadratic'] = {
                        'status': 'passed' if quadratic_error <= 1e-10 else 'failed',
                        'max_abs_error': quadratic_error,
                        'formula': 'F=F0+P0*t+C0*t^2/2'}
                else:
                    row['exact_quadratic'] = {'status': 'not_applicable',
                                               'max_abs_error': None}
                row['integral'] = _integral_drift(reduction, rkf.t, rkf.y, exponent)
                row['second_order'] = _second_order_check(reduction, grid, rkf.y, y0, exponent)
                row['pde'], row['negative_control'] = _pde_check(
                    reduction, reference.sol, interval, case, exponent)
                row['pde']['trajectory'] = 'DOP853 reference reconstruction'
                rkf_pde, _ = _pde_check(reduction, _rkf_interpolant(grid, tighter.y),
                                       interval, case, exponent)
                rkf_pde['trajectory'] = 'tight RKF45 local degree-11 interpolation'
                row['rkf_pde'] = rkf_pde
                margins = np.array([[float(fn(z, *state)) for z, state in zip(grid, rkf.y.T)]
                                    for fn in functions[1:]], dtype=float)
                row['branch'] = {'min_velocity': float(np.min(margins[1])),
                                 'min_gradient': float(np.min(margins[2])),
                                 'min_abs_leading': float(np.min(np.abs(margins[0]))),
                                 'sample_count': len(grid)}
                stem = f"{case.replace('.', '-')}-m{str(exponent).replace('.', 'p')}"
                csv_path, plot_path = output / f'{stem}.csv', output / f'{stem}.png'
                with csv_path.open('w', newline='', encoding='utf-8') as handle:
                    writer = csv.writer(handle)
                    writer.writerow(('z', 'F_rkf45', 'P_rkf45', 'C_rkf45',
                                     'F_dop853', 'P_dop853', 'C_dop853'))
                    writer.writerows(zip(grid, *rkf.y, *reference.y))
                _write_plot(plot_path, grid, rkf.y, case, exponent)
                row['csv'], row['plot'] = str(csv_path), str(plot_path)
                gates = (disagreement <= 1e-7, tight_disagreement <= 1e-7,
                         distinct, row['exact_quadratic']['status'] != 'failed',
                         row['pde']['status'] == 'passed',
                         row['rkf_pde']['status'] == 'passed',
                         row['negative_control']['passed'],
                         row['integral']['status'] != 'failed',
                         row['second_order']['status'] != 'failed',
                         row['branch']['min_abs_leading'] > 1e-10,
                         row['branch']['min_velocity'] > 0,
                         row['branch']['min_gradient'] > 0)
                row['status'] = 'passed' if all(gates) else 'failed_gate'
            except (ValueError, ZeroDivisionError, OverflowError, FloatingPointError) as exc:
                row['status'] = 'unresolved_exception'
                row['error'] = f'{type(exc).__name__}: {exc}'
    report = {'settings': {'rtol': rtol, 'atol': atol,
                           'rkf_tableau': 'classic six-stage Fehlberg 4(5)',
                           'reference': 'SciPy DOP853, independent comparator',
                           'pde_gate': 1e-6, 'solver_and_integral_gate': 1e-7},
              'runs': runs, 'non_numerical': non_numerical,
              'all_passed': bool(runs) and all(r['status'] == 'passed' for r in runs)}
    (output / 'numerics.json').write_text(json.dumps(report, indent=2, allow_nan=False), encoding='utf-8')
    return report
