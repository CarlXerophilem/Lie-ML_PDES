"""Transcribed testable source assertions and exact substitution witnesses.

Reference: Paliathanasis--Leon--Leach, Mathematics 14 (2026), 433, v3,
pp. 6--9, Table 3 and equations (24)--(34). OCR-ambiguous expanded equations
are not silently treated as authoritative symbolic expressions.
"""
import sympy as sp

from . import core as j
from .reductions import derive_reduction


def cubic_power_law_audit():
    """Equations (24)--(26): exact profile, condition, and ODE-chart type."""
    A = sp.symbols('A', positive=True)
    jets = {j.F:A*j.z**sp.Rational(1,3),
            j.P:A*j.z**sp.Rational(-2,3)/3,
            j.C:-2*A*j.z**sp.Rational(-5,3)/9,
            j.H:10*A*j.z**sp.Rational(-8,3)/27}
    beta = 3*j.kappa
    condition = sp.expand((4*beta*j.g-1)*A**3+27*j.g)
    x4 = derive_reduction('3.4')
    x5 = derive_reduction('3.5')
    return {'profile':jets[j.F], 'condition_printed':condition,
            'x4_residual':sp.factor(x4['residual'].subs(jets)),
            'x5_residual':sp.factor(x5['residual'].subs(jets)),
            'x4_leading':sp.factor(x4['leading'].subs(jets)),
            'x5_leading':sp.factor(x5['leading'].subs(jets)),
            'domain':'z>0, A>0, g>0, kappa>0; x4 normal-form coefficient vanishes on the printed condition'}


def translated_ansatz_witnesses():
    """Table 3 versus subsections 3.1--3.2 and 3.7--3.8."""
    # At alpha=1, F'=2, source 3.7/3.8 displayed graphs fail Q=0.
    # The source 3.8 graph alpha*t+F(s) actually has zero PDE residual
    # for any F(s), including an F with nonzero third derivative.
    return {'3.1_source_graph_Q_at_Fprime_2':sp.Integer(-2),
            '3.2_source_graph_Q_at_Fprime_2':sp.Integer(-2),
            '3.7_source_graph_Q_at_alpha_1_Fprime_2':sp.Integer(-1),
            '3.8_source_graph_Q_at_alpha_1_Fprime_2':sp.Integer(-1),
            '3.8_wrong_graph_counterexample': {
                'phi':j.t+j.s+j.s**3/6,
                'phi_s':1+j.s**2/2,
                'phi_t':sp.Integer(1),
                'F_sss':sp.Integer(1),
                'original_PDE':sp.Integer(0),
                'note':'For any real s this is q>0 and p>0; it violates the printed F_sss=0 requirement while solving the printed scalar PDE.'}}


def traveling_first_integral(exponent=3, alpha=-1, alpha3=1):
    """Exact first integral of (28)/(33) with its free integration constant."""
    exponent,alpha,alpha3 = map(sp.sympify,(exponent,alpha,alpha3))
    v = alpha3-alpha*j.P
    B = sp.factor(alpha**2*j.P-j.g/j.P**2
                  -j.g*exponent*j.kappa*v**(exponent-1)/j.P)
    I = B*j.C
    # Y(P)=integral B(P)dP locally. A second derivative of Y(P(z))
    # is B*H+B'*C^2, so the reduced equation is -alpha*Y''=0.
    return {'B':B, 'I':I, 'dI':sp.factor(j.profile_total(I)),
            'linearization':'Y(P)=Integral(B(P),dP); Y(z) is affine if B(P)!=0',
            'quadrature':'z-z0=(Integral(B(P),dP)-Y0)/I0 for I0!=0; I0=0 implies P constant on B!=0 chart',
            'domain':'P>0, alpha3-alpha*P>0, alpha!=0, B(P)!=0'}


def common_scaling_first_integral(exponent=3):
    """Exact X4 certificate for all real exponents on the positive chart."""
    exponent = sp.sympify(exponent)
    velocity = j.F-j.z*j.P
    I = j.C*(-j.z**3*j.P+j.g*j.z/j.P**2+
             j.g*exponent*j.kappa*j.z*velocity**(exponent-1)/j.P)
    return {'I':sp.factor(I), 'dI':sp.factor(j.profile_total(I)),
            'domain':'z>0, P>0, F-z*P>0; all real m; I is constant on reduced solutions'}


def printed_equation_witnesses():
    """Page-image-checked equations (25),(27),(29)--(31),(33), cubic slice.

    Source expressions are transcribed on their displayed normalization. A
    zero of a source formula with nonzero original pullback disproves even
    equivalence up to a nonvanishing multiplier.
    """
    P,C,H,Z,G,K = j.P,j.C,j.H,j.z,j.g,j.kappa
    beta = 3*K
    point = {Z:1,P:sp.Rational(1,2),C:sp.Rational(1,10),
             G:1,K:sp.Rational(1,30)}
    V = j.F-Z*P
    source24 = (-Z**2*P**3*(Z*j.profile_total(P*C)+3*P*C)
                +G*P*j.profile_total(Z*C)-2*G*Z*C**2
                +G*beta*Z*P*V*2*Z**2*C**2
                -V**2*P*((Z*H+2*C**2)*P-Z*C**2))
    point24 = {**point, j.F:2}
    h24 = sp.solve(source24.subs(point24),H)[0]
    source25 = (4*Z*P**3*C*(Z*C+3*P)+2*G*C**2+
                beta*Z*((Z*C+5*P)*Z*C+(2*P+Z**2*H)*P))
    h25 = sp.solve(source25.subs(point),H)[0]
    source29 = (P*((P*C)**2+H*(P**3-G))-
                beta*G*P**3*(C+P*H))  # alpha=-1, m=3
    h29 = sp.solve(source29.subs(point),H)[0]
    source28 = source29-beta*G*P**4*H
    h28 = sp.solve(source28.subs(point),H)[0]
    v = 1+P
    source33 = (P*((P*C)**2+H*(P**3-G))-
                beta*G*(v**3*P*(C+P*H)-v*H))
    h33 = sp.solve(source33.subs(point),H)[0]
    sigma, M = sp.symbols('Sigma M', positive=True)
    den27 = 4*sigma**3*(beta*G-1)+G
    source27 = (2*(G+(4*beta*G-1)*sigma**3)*sigma*M**3/(9*den27)
                +(8*sigma**3*(1+2*beta*G)+G)*M**2/(3*den27)
                +2*(2*sigma**3*(beta*G-1)-G)*M/(sigma*den27))
    x5 = derive_reduction('3.5')
    transformed_h = x5['rhs'].subs({P:sigma*Z**sp.Rational(-2,3),
                                     C:M*Z**sp.Rational(-5,3)})
    exact27 = sp.factor((sp.Rational(5,3)*M+Z**sp.Rational(8,3)*transformed_h)
                         /(sp.Rational(2,3)*sigma+M))
    sample27 = {sigma:1,M:1,G:1,K:sp.Rational(1,30),Z:1}
    B = traveling_first_integral(3,-1,0)['B']
    source30_slope = (P**3+beta*P**2+2*G)/(P*(G-P**2+P**3))
    correct30_slope = -sp.diff(B,P)/B
    source31 = beta*G*P**2/((1+beta*G)*P**3+G)  # M0=1, exp(-2*pi*i)=1
    # Literal (34), with lower integration limit P0=1. The displayed
    # integrand contains the coordinate z rather than dummy variable tau.
    D34 = G/P**2-Z+beta*G*(1+P)**2/P
    c34 = sp.factor((1+(P-1))/D34).subs(point)
    h34 = sp.factor((2*c34-sp.diff(D34,P).subs(point)*c34**2)
                    /D34.subs(point))
    data = {
        'eq24':{'printed_H_zero':h24,
                'original_residual_at_zero':sp.factor(derive_reduction('3.4')['residual'].subs(point24).subs(H,h24))},
        'eq25':{'printed_H_zero':h25,
                'original_residual_at_zero':sp.factor(x5['residual'].subs(point).subs(H,h25))},
        'eq26':{'printed_mu_second_zero':h25,
                'correct_mu_equation_at_zero':sp.factor(x5['residual'].subs(point).subs(H,h25))},
        'eq27':{'printed_Mprime_at_sample':sp.factor(source27.subs(sample27)),
                'correct_Mprime_at_sample':sp.factor(exact27.subs(sample27)),
                'correct_rhs':exact27},
        'eq28':{'printed_H_zero':h28,
                'original_residual_at_zero':sp.factor(derive_reduction('3.6')['residual'].subs(point).subs(H,h28))},
        'eq29':{'printed_H_zero':h29,
                'original_residual_at_zero':sp.factor(derive_reduction('3.6')['residual'].subs(point).subs(H,h29))},
        'eq30':{'printed_Mprime_over_M_at_sample':sp.factor(source30_slope.subs(point)),
                'correct_Mprime_over_M_at_sample':sp.factor(correct30_slope.subs(point))},
        'eq31':{'printed_M':source31,
                'd_of_correct_integral_dP_at_sample':sp.factor(sp.diff(B*source31,P).subs(point))},
        'eq33':{'printed_H_zero':h33,
                'original_residual_at_zero':sp.factor(derive_reduction('3.9')['residual'].subs(point).subs(H,h33))},
        'eq32':{'printed_quadratic_is_solution':True,
                'not_necessary_witness':'phi=t+s+s^3/6 has p=1, q=1+s^2/2>0, E=0, but F_sss=1'},
        'eq34':{'literal_implicit_first_derivative':'D(z,P)*C-(P-1)-1=0, D=g/P^2-z+beta*g*(1+P)^2/P',
                'literal_implied_C':c34,'literal_implied_H':h34,
                'original_residual_at_implied_jet':sp.factor(derive_reduction('3.9')['residual'].subs({Z:1,P:sp.Rational(1,2),G:1,K:sp.Rational(1,30),C:c34,H:h34}, simultaneous=True)),
                'correct_integrand':'g/tau^2-alpha^2*tau+beta*g*(alpha3-alpha*tau)^(m-1)/tau',
                'note':'Even corrected integrand with coefficient 1 fixes first-integral constant I=-1; general I0 must be retained.'},
        'sample':{'m':3,'alpha':-1,'alpha3':1,'g':1,'kappa':'1/30',
                  'z':1,'P':'1/2','C':'1/10','Sigma':1,'M':1}}
    metadata = {
      'eq24':('refuted_as_printed','p.7 eq(24)','Literal displayed expanded beta terms; positive jet F=2,P=1/2,C=1/10'),
      'eq25':('refuted_as_printed','p.7 eq(25)','Displayed X5 third-order equation'),
      'eq26':('refuted_as_printed','p.7 eq(26)','Equation (25) with mu=phi_sigma, hence same failed zero'),
      'eq27':('refuted_as_printed','p.7 eq(27)','Displayed Abel-type polynomial RHS for M_Sigma'),
      'eq28':('refuted_as_printed','p.7 eq(28)','Traveling expanded equation with alpha=-1,m=3'),
      'eq29':('refuted_as_printed','p.8 eq(29)','Displayed mu second-order equation, alpha=-1,m=3'),
      'eq30':('refuted_as_printed','p.8 eq(30)','Displayed M_Xi/M logarithmic derivative'),
      'eq31':('refuted_as_printed','p.8 eq(31)','Displayed complex-form M(Xi), real cubic slice M0=1'),
      'eq32':('qualified','p.8 eq(32)','Quadratic F(s) is sufficient but not necessary for printed wrong 3.8 graph'),
      'eq33':('refuted_as_printed','p.8 eq(33)','Mixed traveling expanded equation alpha=-1,alpha3=1,m=3'),
      'eq34':('refuted_as_printed','p.9 eq(34)','Literal -alpha^2*kappa in integrand; lower limit P0=1')}
    for key,(status,source,printed) in metadata.items():
        data[key].update(status=status,source=source,printed=printed,
                         domain='g=1,kappa_physical=1/30,m=3; positive P and velocity; see sample')
    return data
