"""Account for each numbered source item without calling definitions theorems."""
from .sources import equation_inventory


def build_coverage(evidence):
    rows=equation_inventory()
    witnesses=evidence.get('reductions',{}).get('source_witnesses',{})
    for row in rows:
        n=row['equation']
        if n<=4:
            row.update(status='model_assumption', evidence='models: coordinate pullback; the Eulerian balances and power closure are input assumptions, not empirical validation.')
        elif n==5:
            row.update(status='verified',evidence='models.checks.momentum_pullback_zero')
        elif n==6:
            row.update(status='corrected_under_declared_bed_pullback',evidence='models.discrepancies.D-MODEL-06; missing -(phi_t/phi_s)b_s')
        elif n==7:
            row.update(status='verified_for_printed_pair',evidence='models.checks.printed_compatibility_zero; source equation retained')
        elif n in (8,9,10,11,12,15,17,19,20,21):
            row.update(status='definition_reproduced',evidence=('symmetries and core.prolongation' if n<19 else 'algebra.formulas.adjoints and orbits'))
        elif n in (13,14):
            row.update(status='qualified',evidence='Use pr(X)E=0 ON E=0, or pr(X)E=lambda E off shell; the literal unconditional zero condition rejects scaling.')
        elif n in (16,18):
            row.update(status='verified',evidence='core.prolongation recursive formula; unrestricted determining split and direct polynomial substitution tests')
        elif n in (22,23):
            row.update(status='verified_on_recorded_charts',evidence='reductions.cases and table3_mixed: Q, invariant coordinates and complete jet pullbacks')
        else:
            witness=witnesses.get(f'eq{n}')
            if witness is None:
                row.update(status='unresolved',evidence=f'No source_witnesses.eq{n} result exists in this run.')
            else:
                row.update(status=witness.get('status','unresolved'),evidence=f'reductions.source_witnesses.eq{n}',detail=witness)
    extra=[
        {'source':'p.4 Proposition 1','status':'corrected','evidence':'symmetries.claims.maximal_classification; the m=1 stratum has X6=t*d_phi'},
        {'source':'p.4 printed determining system','status':'refuted_as_printed','evidence':'symmetries.discrepancies.printed_determining_X4_witness'},
        {'source':'pp.5-6 optimal system','status':'corrected','evidence':'algebra.formulas.orbits; missing projective/resonant families'},
        {'source':'p.7 reduced generators after (25) and (26)','status':'corrected',
         'printed':'3*sigma*d_sigma+phi*d_sigma and 3*sigma*d_sigma-2*mu*d_sigma',
         'derived':'3*sigma*d_sigma+phi*d_phi and 3*sigma*d_sigma-2*mu*d_mu',
         'evidence':'X4(s*t^2)=3*s*t^2 and X4(phi)=phi; prolongation to mu=phi_sigma gives mu-3*mu=-2*mu.'},
        {'source':'p.8 eight-generator/free-particle statement','status':'qualified','evidence':'corrected traveling derivative ODE has invertible Y(P)=Integral(B(P),dP) on B!=0, giving Y_second=0'},
        {'source':'pp.7-8 shock/nonsingular descriptions','status':'unsupported_as_global_claim','evidence':'local smooth-profile checks do not establish weak shock balances or global absence of singularities'},
        {'source':'p.9 variational Lagrangian','status':'author_reported_negative','evidence':'authors report not finding a formulation; no nonexistence proof follows'},
        {'source':'p.9 initial-value discussion','status':'source_text_inconsistent','evidence':'conclusion both says IVP was examined and later says it was not discussed; paper supplies no numerical initial data'}]
    return {'equations':rows,
            'tables':[{'table':1,'page':5,'status':'corrected','evidence':'algebra.formulas.brackets; two source sign errors'},
                      {'table':2,'page':5,'status':'verified','evidence':'algebra.formulas.adjoints; convention exp(-epsilon ad)'},
                      {'table':3,'page':6,'status':'qualified','evidence':'recorded invariants verified; alpha=-1 requires a separate chart and the list omits other orbit families'}],
            'unnumbered_claims':extra,
            'inventory_complete':len(rows)==34 and all(row['status']!='pending_evidence' for row in rows),
            'all_printed_claims_reproduced':False}
