# Executable reproduction of the scalar SVE paper

This package audits Paliathanasis, Leon and Leach, *Mathematics* 14 (2026),
433, DOI `10.3390/math14030433`, using the supplied v3 PDF. It preserves the
printed source, independently derives the mathematics, and records corrections
with explicit witnesses. Source agreement and successful software execution
are different fields in the evidence report.

Open [solutions.html](solutions.html) for the offline time animation of source
equations (24)--(33), reconstructed position/velocity/depth fields, and measured
convergence tables. [RESULTS_EXPLAINED.md](RESULTS_EXPLAINED.md) answers the
paper-correctness, reconstruction, and variational-Lagrangian questions.
All implementation code is now ordinary source in **one `main.py`**, including
the HTML template. The prior modular release is preserved in
`archive/release-before-animation.zip`.

## Run

From the repository root, with Python, SymPy, NumPy, SciPy, Matplotlib,
PyMuPDF and pytest installed:

```powershell
python research_artifacts/SVE-reproduced-20261012/main.py
```

The default prints symbolic steps, runs the numerical campaign and independent
convergence sweeps, and regenerates `solutions.html`. Numerical results go
to this package's `results/` directory. Run from the package directory with
`python main.py`; all paths are resolved relative to the script, not the shell.

```powershell
python main.py --stage symbolic
python main.py --stage all --reduction 3.5 --case 3 --trace summary
python main.py --stage all --rtol 1e-10 --atol 1e-12 --out build/tighter
python main.py --stage report
python main.py --stage convergence
python main.py --stage html
python -B -m pytest -q tests
```

`--case` selects the numerical exponent from `1, 1.5, 2, 3, 4`; `all` is the default.
The displayed profile-jet examples use the cubic case; the symbolic symmetry
classification and general formulas cover the declared parameter strata.
`--reduction` selects the paper subsection `3.1`--`3.9` or `table3-mixed`.
Non-ODE rows receive explicit statuses rather than fabricated IVPs. The mixed
Table 3 calculation is a symbolic companion, separate from the numbered nine.
Use `--html-out PATH` to select a different explorer output. Top-level
`DEFAULT_RTOL`, `DEFAULT_ATOL`, `G`, `KAPPA`, and
`NUMERICAL_CASE_SETTINGS` locate the main numerical settings for editing.
The source sections remain explicit and searchable. A copied `main.py` can
run without this directory; `--repo-root PATH` locates the reference PDFs.
Missing sources are recorded as unavailable, not silently verified.

## Read the output

- `results/REPORT.md`: all ten requested headings, source inventory, formulas,
  exact checks, detailed derivations, numerical metrics and limitations.
- `results/convergence/`: fixed-step and tolerance-only endpoint experiments,
  including a non-polynomial exact control and explicit error-floor decisions.
- `REVISION_VALIDATION.md`: checks of the single-file revision and browser,
  alongside the earlier `VALIDATION.md` release record.
- `results/evidence.json`: machine-readable counterpart, including per-claim
  statuses. `source_manifest.json` records source hashes and environment.
- `results/symbolic_steps.txt`: the printed calculation trace, including every
  derivative substitution and reduced equation.
- `results/numerical/`: numerical CSV data, profile plots, and solver receipts.
- `docs/`: detailed mathematical proofs and method explanations.
- `RUN_CONTRACT.md`, `LEDGER.json`: approved scope, task ownership and review.

The jet notation is
`p=phi_t, q=phi_s, a=phi_tt, b=phi_ts, c=phi_ss, r=phi_ttt,
w=phi_tts, x=phi_tss, y=phi_sss`. Here the jet `b` is distinct from a bed
function named `b(t,s)` in the physical-coordinate audit.

For a profile, `F,P,C,H` mean `F,F',F'',F'''`. A Lie generator gives a way to
compress two independent variables into one invariant coordinate. Requiring
the solution graph to follow that symmetry gives a profile ODE; finding a
first integral is a separate step that can lower its order.

## Scope and numerical defaults

The mathematical target is the **printed scalar equation (7)**. Its physically
advected bed counterpart is shown only in the model audit. The local symmetry
classification uses `g,kappa>0`, `m>=1`, and `phi_t,phi_s>0`. Stationary and
singular cases are retained separately; no global or arbitrary-data theorem is
claimed. The corrected classification must account for both `m=1` and `m=3`.

The numerical runs are newly constructed dimensionless IVPs, not data supplied
by either paper. They use `g=1`, `kappa=1/30`, `beta=m*kappa`, with nonlinear
initial jet `(2,.5,.1)` at reduced coordinate 1. Common scaling uses the existing
regular comparison interval `[1,1.4]`; the other nonlinear cases use `[1,1.1]`.
The linear case 3.8 uses `(0,1,.1)` at time 0 on `[0,.4]`.

The default integrator is the **classic six-stage Fehlberg 4(5)** pair, with
fifth-order accepted values, `rtol=1e-9`, `atol=1e-11`. SciPy `RK45` is a
different Dormand--Prince formula and is not used as a Fehlberg substitute.
Uddin et al., DOI `10.1016/j.aej.2016.05.009`, motivate this method but solve
a different boundary-value problem; their shooting data are not SVE data.

State agreement and integral drift target `1e-7`. Independent original-PDE
finite differences target `1e-6` at a declared stencil size and retain their
refinement/roundoff diagnostics. These are sampled numerical checks, not
continuous error bounds. The source's cubic power law lies on a degenerate
normal-form branch and is checked exactly instead of dividing by zero.

## Dissertation and validation

The reviewed section is included in `draft/main.tex`. Run the repository's
README audit, data-flux, workflow, chart/engine and historical-package checks,
then native `latexmk` and inspect the rendered manuscript. Existing frozen
evidence and unrelated working-tree changes are preserved.
